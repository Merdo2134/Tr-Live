import { Router } from 'express';
import express from 'express';
import { query, tx } from '../database.js';
import { requireAuth, requireStaff, requireSuperAdmin, hashPassword, passwordRules } from '../auth.js';
import { USERNAME_RE, normalizePhone } from './auth.js';
import { supportMayCall, banEnd, mayActOnUser } from '../staff_logic.js';
import { fail, uuid, bigAmount, positiveInt, text, oneOf, httpsUrl, assetUrl } from '../http.js';
import { prepareMp4 } from '../services/media_tools.js';
import { applyPackZip, packStatus } from '../asset_packs.js';
import { SERVER_VERSION } from './system.js';
import { validateAgencyConfig } from '../agency_config.js';
import { loadConfig, configJson, closePeriod, hostStatementJson, agencyStatementJson } from '../services/payouts.js';
import { parsePeriodKey, previousPeriod } from '../settlement.js';
import { ensureAgencyCode } from './agencies.js';
import { equipIfNone, announceUserChange } from '../services/users.js';
import { EVENT_KINDS, EVENT_TITLES, isStar, validateRewards, rewardsView, defaultRules } from '../services/weekly_events.js';
import { cleanPublic } from '../safe_text.js';
import { WIP_MIN_LEVEL, WIP_MAX_LEVEL } from '../levels.js';
import { wipLabel } from '../services/wip.js';
import { dealerSell } from '../services/dealers.js';
import { hub } from '../realtime.js';
import { leaveRoom } from '../services/rooms.js';
import { banIpPersist, unbanIp, listBans, securityStats, userLimit } from '../firewall.js';
import net from 'node:net';
import { saveUpload, removeUpload, removeAnimatedAvatar, IMAGE_TYPES, OWN_IMAGE_RE } from '../services/images.js';
import { revokeAllSessions } from '../services/sessions.js';
import { detectMedia, ensureVapc, mimeFor, MEDIA_MAX_BYTES } from '../services/media.js';
import { mediaCacheStats } from '../services/images.js';
import { getConfig, saveConfig, validateConfigPatch, compareVersions, CONFIG_DEFAULTS } from '../services/app_config.js';
import { livekitHealth } from '../livekit.js';
import { poolStats } from '../database.js';
import fs from 'node:fs';
import os from 'node:os';
import { idempotent } from '../idempotency.js';
import { ghostNow, refreshGhost } from '../services/ghost.js';

export const router = Router();
router.use(requireAuth, requireStaff);
// Yardımcı admin ('support') yalnızca dar yetkilere sahiptir (nick, profil fotoğrafı, ban). Diğer her şey yöneticiye aittir.
router.use((req, res, next) => {
  if (req.user.system_role === 'admin') return next();
  if (supportMayCall(req.method, req.path)) return next();
  next(fail('Bu işlem yalnızca yöneticiye aittir.', 403));
});

router.get('/me/permissions', (req, res) => {
  const admin = req.user.system_role === 'admin';
  res.json({ role: req.user.system_role, full: admin, can: admin ? ['all'] : ['search_users', 'ban', 'unban', 'change_display_name', 'change_avatar'] });
});

const INVENTORY_TYPES = ['frame', 'entrance_effect', 'badge', 'profile_effect'];
const wipLevel = (v) => {
  const n = positiveInt(v, 'WIP seviyesi');
  if (n < WIP_MIN_LEVEL || n > WIP_MAX_LEVEL) throw fail(`WIP seviyesi ${WIP_MIN_LEVEL}-${WIP_MAX_LEVEL} arasında olmalı.`);
  return n;
};

async function assertUser(id, run = query) {
  const u = (await run(`SELECT id, username, system_role, account_status FROM users WHERE id = $1`, [id])).rows[0];
  if (!u) throw fail('Kullanıcı bulunamadı.', 404);
  return u;
}

// ---------------- Kullanıcı arama ve durum ----------------
router.get('/users', async (req, res) => {
  const q = String(req.query.q ?? '').trim().toLowerCase();
  if (q.length < 2) throw fail('Arama için en az 2 karakter girin.');
  const r = await query(
    `SELECT id, public_id, username, display_name, avatar_url, coins, diamonds, system_role, account_status, banned_until, ban_reason, chat_restricted_until
     FROM users WHERE lower(username) LIKE $1 ESCAPE '\\' OR lower(display_name) LIKE $1 ESCAPE '\\' OR id::text = $2 OR public_id = $2
     ORDER BY (public_id = $2) DESC, username LIMIT 20`,
    [`%${q.replace(/[\\%_]/g, (m) => `\\${m}`)}%`, q],
  );
  res.json({
    users: r.rows.map((u) => ({
      id: u.id, publicId: u.public_id ?? null, username: u.username, displayName: u.display_name, coins: String(u.coins), diamonds: String(u.diamonds),
      systemRole: u.system_role, accountStatus: u.account_status, avatarUrl: u.avatar_url, bannedUntil: u.banned_until, banReason: u.ban_reason,
      chatRestrictedUntil: u.chat_restricted_until && new Date(u.chat_restricted_until) > new Date() ? u.chat_restricted_until : null,
      ...(req.user.system_role === 'admin' ? {} : { coins: undefined, diamonds: undefined }),
    })),
  });
});

async function auditStaff(c, adminId, userId, action, meta) {
  await c.query(
    `INSERT INTO financial_audit_logs(admin_id, user_id, action, reference_type, metadata) VALUES($1,$2,$3,'user',$4)`,
    [adminId, userId, action, JSON.stringify(meta)],
  );
}

// Süreli veya süresiz ban. hours yoksa/0 ise süresiz.
router.post('/users/:userId/ban', async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  if (userId === req.user.id) throw fail('Kendinizi banlayamazsınız.');
  const target = await assertUser(userId);
  if (target.account_status === 'deleted') throw fail('Silinmiş hesap değiştirilemez.', 409);
  if (!mayActOnUser(req.user.system_role, target.system_role)) throw fail('Bu hesap üzerinde işlem yetkiniz yok.', 403);
  const until = banEnd(req.body?.hours);
  if (until === undefined) throw fail('Süre 1 saat ile 1 yıl arasında olmalı (süresiz için boş bırakın).');
  const reason = text(req.body?.reason, 'Neden', { max: 300 });
  await tx(async (c) => {
    await c.query(
      `UPDATE users SET account_status = 'banned', banned_until = $2, ban_reason = $3, banned_by = $4, token_version = token_version + 1, updated_at = NOW() WHERE id = $1`,
      [userId, until, reason, req.user.id],
    );
    await auditStaff(c, req.user.id, userId, 'account_ban', { until, reason, by: req.user.system_role });
  });
  await revokeAllSessions(userId, 'banned');
  hub.disconnectUser(userId, 'banned');
  // Banlanan kullanıcı odalardan çıkarılır; ses/görüntü (LiveKit) bağlantısı da kesilir, sahibi olduğu oda kapanır.
  for (const r of (await query(`SELECT room_id FROM room_members WHERE user_id = $1`, [userId])).rows) {
    await leaveRoom(userId, r.room_id).catch((e) => console.error('Ban sonrası odadan çıkarma:', e.message));
  }
  res.json({ ok: true, status: 'banned', bannedUntil: until });
});

router.post('/users/:userId/unban', async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const target = await assertUser(userId);
  if (!mayActOnUser(req.user.system_role, target.system_role)) throw fail('Bu hesap üzerinde işlem yetkiniz yok.', 403);
  if (target.account_status !== 'banned') throw fail('Hesap banlı değil.', 409);
  await tx(async (c) => {
    await c.query(`UPDATE users SET account_status = 'active', banned_until = NULL, ban_reason = NULL, banned_by = NULL, updated_at = NOW() WHERE id = $1`, [userId]);
    await auditStaff(c, req.user.id, userId, 'account_unban', { by: req.user.system_role });
  });
  res.json({ ok: true, status: 'active' });
});

// Kullanıcının görünen adını (nick) değiştirir. Yasaklı kelime denetimi uygulanmaz (yetkili işlemi) ama uzunluk denetlenir.
router.post('/users/:userId/display-name', async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const name = text(req.body?.displayName, 'Görünen ad', { min: 2, max: 40, required: true });
  const target = await assertUser(userId);
  if (target.account_status === 'deleted') throw fail('Silinmiş hesap değiştirilemez.', 409);
  if (!mayActOnUser(req.user.system_role, target.system_role, userId === req.user.id)) throw fail('Bu hesap üzerinde işlem yetkiniz yok.', 403);
  await tx(async (c) => {
    const before = (await c.query(`SELECT display_name FROM users WHERE id = $1`, [userId])).rows[0]?.display_name;
    await c.query(`UPDATE users SET display_name = $2, updated_at = NOW() WHERE id = $1`, [userId, name]);
    await auditStaff(c, req.user.id, userId, 'profile_display_name', { before, after: name, by: req.user.system_role });
  });
  res.json({ ok: true, displayName: name });
});

// Profil fotoğrafını kaldırır (avatarUrl boş) veya https adresiyle değiştirir.
router.post('/users/:userId/avatar', async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const url = httpsUrl(req.body?.avatarUrl, 'Fotoğraf adresi');
  const target = await assertUser(userId);
  if (target.account_status === 'deleted') throw fail('Silinmiş hesap değiştirilemez.', 409);
  if (!mayActOnUser(req.user.system_role, target.system_role, userId === req.user.id)) throw fail('Bu hesap üzerinde işlem yetkiniz yok.', 403);
  const before = (await query(`SELECT avatar_url, static_avatar_url, avatar_animated FROM users WHERE id = $1`, [userId])).rows[0];
  await tx(async (c) => {
    await c.query(`UPDATE users SET avatar_url = $2, avatar_animated = FALSE, static_avatar_url = NULL, updated_at = NOW() WHERE id = $1`, [userId, url]);
    await auditStaff(c, req.user.id, userId, 'profile_avatar', { removed: !url, by: req.user.system_role });
  });
  // Kaldırılan fotoğrafın dosyası da silinir (yalnızca kullanıcının kendi yüklediği kayıt).
  await removeUpload(before?.avatar_url, userId);
  await removeUpload(before?.static_avatar_url, userId);
  if (before?.avatar_animated) await removeAnimatedAvatar(before.avatar_url, userId);
  res.json({ ok: true, avatarUrl: url });
});

// Yardımcı admin atama/alma: yalnızca yönetici, admin panelinden.
router.post('/users/:userId/staff-role', requireSuperAdmin, async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const role = oneOf(req.body?.role, ['user', 'support'], 'Rol');
  if (userId === req.user.id) throw fail('Kendi rolünüzü değiştiremezsiniz.');
  const target = await assertUser(userId);
  if (target.system_role === 'admin') throw fail('Yönetici rolü buradan değiştirilemez.', 403);
  if (target.account_status !== 'active') throw fail('Yalnızca aktif hesaplara yetki verilebilir.', 409);
  await tx(async (c) => {
    await c.query(`UPDATE users SET system_role = $2, updated_at = NOW() WHERE id = $1`, [userId, role]);
    await auditStaff(c, req.user.id, userId, 'staff_role', { role });
  });
  res.json({ ok: true, role });
});

router.get('/staff', requireSuperAdmin, async (req, res) => {
  const r = await query(`SELECT id, username, display_name, system_role FROM users WHERE system_role IN ('support','admin') ORDER BY system_role, username`);
  res.json({ staff: r.rows.map((u) => ({ id: u.id, username: u.username, displayName: u.display_name, systemRole: u.system_role })) });
});

// ---------------- Coin (yalnızca yönetici) ----------------
router.post('/users/:userId/coins', requireSuperAdmin, idempotent('admin_coins'), async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const delta = bigAmount(req.body?.amount, 'Coin miktarı', { allowNegative: true });
  const reason = text(req.body?.reason, 'Neden', { max: 300 }) || 'Admin Coin düzenlemesi';
  const result = await tx(async (c) => {
    const user = (await c.query(`SELECT coins FROM users WHERE id = $1 AND account_status = 'active' FOR UPDATE`, [userId])).rows[0];
    if (!user) throw fail('Kullanıcı bulunamadı.', 404);
    const before = BigInt(user.coins);
    const after = before + delta;
    if (after < 0n) throw fail('Bakiye negatife düşemez.');
    await c.query(`UPDATE users SET coins = $1, updated_at = NOW() WHERE id = $2`, [after.toString(), userId]);
    await c.query(
      `INSERT INTO wallet_transactions(user_id, transaction_type, coin_amount, description) VALUES($1,'admin_adjustment',$2,$3)`,
      [userId, delta.toString(), reason],
    );
    await c.query(
      `INSERT INTO financial_audit_logs(admin_id, user_id, action, reference_type, amount_coins, balance_before, balance_after, metadata)
       VALUES($1,$2,'admin_coin_adjustment','user',$3,$4,$5,$6)`,
      [req.user.id, userId, delta.toString(), before.toString(), after.toString(), JSON.stringify({ reason })],
    );
    return { before: before.toString(), after: after.toString() };
  });
  res.json(result);
});

// ---------------- WIP ----------------
router.post('/users/:userId/wip', async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const level = wipLevel(req.body?.level);
  const days = positiveInt(req.body?.days, 'WIP süresi', 3650);
  await assertUser(userId);
  const wasGhost = await ghostNow(userId);
  const r = await query(
    `INSERT INTO user_wip(user_id, level, starts_at, expires_at, is_active)
     VALUES($1,$2,NOW(),NOW() + ($3::int * INTERVAL '1 day'),TRUE)
     ON CONFLICT (user_id) DO UPDATE SET level = EXCLUDED.level, starts_at = EXCLUDED.starts_at, expires_at = EXCLUDED.expires_at, is_active = TRUE
     RETURNING level, starts_at, expires_at`,
    [userId, level, days],
  );
  await query(
    `INSERT INTO financial_audit_logs(admin_id, user_id, action, reference_type, metadata) VALUES($1,$2,'admin_wip_grant','wip',$3)`,
    [req.user.id, userId, JSON.stringify({ level, days })],
  );
  await refreshGhost(userId, wasGhost);
  res.json({ wip: r.rows[0] });
});

router.delete('/users/:userId/wip', async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const wasGhost = await ghostNow(userId);
  await query(`UPDATE user_wip SET is_active = FALSE WHERE user_id = $1`, [userId]);
  await query(`INSERT INTO financial_audit_logs(admin_id, user_id, action, reference_type) VALUES($1,$2,'admin_wip_revoke','wip')`, [req.user.id, userId]);
  await refreshGhost(userId, wasGhost);
  res.json({ ok: true });
});

const FEATURE_TYPES = {
  nameColor: 'color', badge: 'string', maxRooms: 'int', viewVisitors: 'bool', vipGifts: 'bool', muteImmunity: 'bool', kickImmunity: 'bool',
  profileEffect: 'bool', customRoomTheme: 'bool', invisibleVisit: 'bool', animatedAvatar: 'bool', ghostMode: 'bool',
};
function cleanFeatures(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw fail('Özellikler nesne olmalı.');
  const out = {};
  for (const [key, value] of Object.entries(input)) {
    const type = FEATURE_TYPES[key];
    if (!type) throw fail(`Bilinmeyen özellik: ${key}`);
    if (type === 'bool' && typeof value !== 'boolean') throw fail(`${key} true/false olmalı.`);
    if (type === 'int' && (!Number.isInteger(value) || value < 1 || value > 50)) throw fail(`${key} 1-50 arasında tam sayı olmalı.`);
    if (type === 'color' && value !== null && !/^#[0-9a-fA-F]{6}$/.test(String(value))) throw fail(`${key} #RRGGBB olmalı.`);
    if (type === 'string' && value !== null && (typeof value !== 'string' || value.length > 40)) throw fail(`${key} geçersiz.`);
    out[key] = value;
  }
  return out;
}

router.patch('/wip/tiers/:level', requireSuperAdmin, async (req, res) => {
  const level = wipLevel(Number(req.params.level));
  const name = req.body?.name !== undefined ? text(req.body.name, 'Ad', { min: 2, max: 60, required: true }) : null;
  const features = req.body?.features !== undefined ? cleanFeatures(req.body.features) : null;
  if (name === null && features === null) throw fail('Değiştirilecek alan yok.');
  const r = await query(
    `UPDATE wip_tiers SET name = COALESCE($2, name), features = features || COALESCE($3::jsonb, '{}'::jsonb) WHERE level = $1 RETURNING level, name, features`,
    [level, name, features ? JSON.stringify(features) : null],
  );
  res.json({ tier: r.rows[0] });
});

router.post('/wip/plans', requireSuperAdmin, async (req, res) => {
  const r = await query(
    `INSERT INTO wip_plans(name, level, duration_days, price_coins) VALUES($1,$2,$3,$4) RETURNING id, name, level, duration_days, price_coins`,
    [text(req.body?.name, 'Ad', { min: 2, max: 100, required: true }), wipLevel(req.body?.level),
      positiveInt(req.body?.durationDays, 'Süre', 3650), bigAmount(req.body?.priceCoins, 'Fiyat').toString()],
  );
  res.status(201).json({ plan: r.rows[0] });
});

// ---------------- Envanter ----------------
router.post('/users/:userId/inventory', async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const itemType = oneOf(req.body?.itemType, INVENTORY_TYPES, 'Öğe tipi');
  const itemKey = text(req.body?.itemKey, 'Öğe anahtarı', { max: 100, required: true });
  const itemName = text(req.body?.itemName, 'Öğe adı', { max: 120, required: true });
  await assertUser(userId);
  if (itemType === 'frame' || itemType === 'entrance_effect') {
    const table = itemType === 'frame' ? 'frames' : 'entrance_effects';
    const exists = await query(`SELECT 1 FROM ${table} WHERE id::text = $1 AND is_active = TRUE`, [itemKey]);
    if (!exists.rowCount) throw fail('Bu anahtara sahip aktif bir katalog öğesi yok.', 404);
  }
  let expiresAt = null;
  if (req.body?.expiresAt) {
    const d = new Date(req.body.expiresAt);
    if (Number.isNaN(d.getTime()) || d.getTime() < Date.now()) throw fail('Bitiş tarihi geçersiz veya geçmişte.');
    expiresAt = d.toISOString();
  }
  const metadata = req.body?.metadata && typeof req.body.metadata === 'object' && !Array.isArray(req.body.metadata) ? req.body.metadata : {};
  const r = await query(
    `INSERT INTO inventory_items(user_id, item_type, item_key, item_name, expires_at, metadata) VALUES($1,$2,$3,$4,$5,$6) RETURNING id`,
    [userId, itemType, itemKey, itemName, expiresAt, JSON.stringify(metadata)],
  );
  await query(
    `INSERT INTO financial_audit_logs(admin_id, user_id, action, reference_type, reference_id, metadata) VALUES($1,$2,'admin_inventory_grant','inventory',$3,$4)`,
    [req.user.id, userId, r.rows[0].id, JSON.stringify({ itemType, itemKey })],
  );
  res.status(201).json({ id: r.rows[0].id });
});

// ---------------- Katalog (yalnızca yönetici) ----------------
function guessFormat(url) {
  const m = /\.([a-z0-9]{2,5})(\?|$)/i.exec(String(url ?? ''));
  const e = (m?.[1] ?? '').toLowerCase();
  return { mp4: 'mp4', svga: 'svga', json: 'lottie', webp: 'webp', gif: 'gif', png: 'png' }[e] ?? 'lottie';
}
// ---------------- Müşteri hizmetleri (admin + yardımcı admin) ----------------
router.get('/support/threads', async (_req, res) => {
  const r = await query(
    `SELECT DISTINCT ON (m.user_id) m.user_id, m.body, m.from_staff, m.created_at, u.username, u.display_name, u.public_id, u.avatar_url,
            (SELECT COUNT(*)::int FROM support_messages x WHERE x.user_id = m.user_id AND x.from_staff = FALSE
               AND x.created_at > COALESCE((SELECT MAX(created_at) FROM support_messages y WHERE y.user_id = m.user_id AND y.from_staff = TRUE), 'epoch')) AS waiting
     FROM support_messages m JOIN users u ON u.id = m.user_id
     ORDER BY m.user_id, m.created_at DESC`,
  );
  const threads = r.rows.sort((a, b) => (b.waiting > 0) - (a.waiting > 0) || new Date(b.created_at) - new Date(a.created_at)).slice(0, 100);
  res.json({ threads: threads.map((t) => ({
    userId: t.user_id, username: t.username, displayName: t.display_name, publicId: t.public_id, avatarUrl: t.avatar_url,
    lastMessage: t.body, lastFromStaff: t.from_staff, lastAt: t.created_at, waiting: t.waiting,
  })) });
});
router.get('/support/:userId', async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const r = await query(`SELECT * FROM support_messages WHERE user_id = $1 ORDER BY created_at DESC LIMIT 200`, [userId]);
  res.json({ messages: r.rows.reverse().map((m) => ({ id: m.id, fromStaff: m.from_staff, category: m.category, text: m.body, createdAt: m.created_at })) });
});
router.post('/support/:userId/reply', async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const body = text(req.body?.text, 'Mesaj', { min: 1, max: 1500, required: true });
  await assertUser(userId);
  const m = (await query(`INSERT INTO support_messages(user_id, from_staff, staff_id, body) VALUES($1,TRUE,$2,$3) RETURNING id`, [userId, req.user.id, body])).rows[0];
  hub.sendToUser(userId, { type: 'support_message' });
  res.status(201).json({ id: m.id });
});

// ---------------- Coin paketleri (yönetici) ----------------
router.get('/coin-packages', requireSuperAdmin, async (_req, res) => {
  const r = await query(`SELECT * FROM coin_packages ORDER BY is_active DESC, sort_order, coins`);
  res.json({ packages: r.rows.map((x) => ({ id: x.id, coins: String(x.coins), priceCents: String(x.price_cents), currency: x.currency, isActive: x.is_active })) });
});
router.post('/coin-packages', requireSuperAdmin, async (req, res) => {
  const coins = bigAmount(req.body?.coins, 'Coin');
  const price = bigAmount(req.body?.priceCents, 'Fiyat (kuruş)');
  const r = await query(`INSERT INTO coin_packages(coins, price_cents, sort_order) VALUES($1,$2,(SELECT COALESCE(MAX(sort_order),0)+1 FROM coin_packages)) RETURNING id`, [coins.toString(), price.toString()]);
  res.status(201).json({ id: r.rows[0].id });
});
router.post('/coin-packages/:id/active', requireSuperAdmin, async (req, res) => {
  if (typeof req.body?.isActive !== 'boolean') throw fail('isActive true/false olmalı.');
  const r = await query(`UPDATE coin_packages SET is_active = $2 WHERE id = $1 RETURNING id`, [uuid(req.params.id, 'Kimlik'), req.body.isActive]);
  if (!r.rowCount) throw fail('Paket bulunamadı.', 404);
  res.json({ ok: true });
});

// Yönetici "öğe ver" listesi: kategoriye göre tüm katalog öğeleri.
router.get('/grantables', requireSuperAdmin, async (req, res) => {
  const category = oneOf(req.query.category, STORE_CATS, 'Kategori');
  let items;
  if (category === 'frame') {
    items = (await query(`SELECT id::text AS key, name, image_url FROM frames WHERE is_active = TRUE ORDER BY name`)).rows;
  } else if (category === 'entrance_effect') {
    items = (await query(`SELECT id::text AS key, name, animation_url AS image_url FROM entrance_effects WHERE is_active = TRUE ORDER BY name`)).rows;
  } else {
    items = (await query(`SELECT id::text AS key, name, image_url FROM store_items WHERE category = $1 AND is_active = TRUE ORDER BY name`, [category])).rows;
  }
  // WIP kademelerinin çerçeve / sohbet balonu / rozet / giriş efekti ayrı ayrı verilebilir (WIP üyeliği olmadan da görünür).
  const wipItems = WIP_GRANT_KIND[category]
    ? Array.from({ length: WIP_MAX_LEVEL }, (_, i) => ({ key: `wip:${i + 1}`, name: `${wipLabel(i + 1)} ${WIP_GRANT_KIND[category]}`, image_url: null }))
    : [];
  res.json({ items: [...wipItems, ...items].map((x) => ({ key: x.key, name: x.name, imageUrl: x.image_url, wip: x.key.startsWith('wip:') })) });
});

// Seçilen katalog öğesini kullanıcıya ver. days boş/0 = süresiz.
router.post('/users/:userId/grant', requireSuperAdmin, async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const category = oneOf(req.body?.category, STORE_CATS, 'Kategori');
  const key = text(req.body?.itemKey, 'Öğe', { min: 1, max: 80, required: true });
  const days = req.body?.days ? positiveInt(req.body.days, 'Gün', 3650) : null;
  await assertUser(userId);
  let name; let asset;
  const wipMatch = /^wip:(\d{1,2})$/.exec(key);
  if (wipMatch) {
    const lvl = Number(wipMatch[1]);
    if (!WIP_GRANT_KIND[category] || lvl < 1 || lvl > WIP_MAX_LEVEL) throw fail('Geçersiz WIP öğesi.');
    const r = await query(
      `INSERT INTO inventory_items(user_id, item_type, item_key, item_name, expires_at, metadata)
       VALUES($1,$2,$3,$4, CASE WHEN $5::int IS NULL THEN NULL ELSE NOW() + ($5::int * INTERVAL '1 day') END, $6) RETURNING id`,
      [userId, category, key, `${wipLabel(lvl)} ${WIP_GRANT_KIND[category]}`, days, JSON.stringify({ wipLevel: lvl, grantedBy: req.user.id })],
    );
    await query(
      `INSERT INTO financial_audit_logs(admin_id, user_id, action, reference_type, reference_id, metadata) VALUES($1,$2,'admin_inventory_grant','inventory',$3,$4)`,
      [req.user.id, userId, r.rows[0].id, JSON.stringify({ category, key, days })],
    );
    return res.status(201).json({ id: r.rows[0].id, name: `${wipLabel(lvl)} ${WIP_GRANT_KIND[category]}` });
  }
  if (category === 'frame') {
    const f = (await query(`SELECT name, image_url FROM frames WHERE id::text = $1`, [key])).rows[0];
    if (!f) throw fail('Çerçeve bulunamadı.', 404);
    ({ name, image_url: asset } = f);
  } else if (category === 'entrance_effect') {
    const f = (await query(`SELECT name, animation_url FROM entrance_effects WHERE id::text = $1`, [key])).rows[0];
    if (!f) throw fail('Efekt bulunamadı.', 404);
    name = f.name; asset = f.animation_url;
  } else {
    const f = (await query(`SELECT name, image_url FROM store_items WHERE id::text = $1 AND category = $2`, [key, category])).rows[0];
    if (!f) throw fail('Ürün bulunamadı.', 404);
    ({ name, image_url: asset } = f);
  }
  const r = await query(
    `INSERT INTO inventory_items(user_id, item_type, item_key, item_name, expires_at, metadata)
     VALUES($1,$2,$3,$4, CASE WHEN $5::int IS NULL THEN NULL ELSE NOW() + ($5::int * INTERVAL '1 day') END, $6) RETURNING id`,
    [userId, category, key, name, days, JSON.stringify({ assetUrl: asset, grantedBy: req.user.id })],
  );
  await equipIfNone(query, userId, category, r.rows[0].id);
  await query(
    `INSERT INTO financial_audit_logs(admin_id, user_id, action, reference_type, reference_id, metadata) VALUES($1,$2,'admin_inventory_grant','inventory',$3,$4)`,
    [req.user.id, userId, r.rows[0].id, JSON.stringify({ category, key, days })],
  );
  res.status(201).json({ id: r.rows[0].id, name });
  announceUserChange(userId);
});

// Test örnekleri: her görünüm türünden birer örnek ürün (mağazada satılmaz) oluşturur ve yöneticinin kendisine
// 30 günlüğüne verip takar. Odaya girince araç, sohbette balon, mikrofonda dalga, profil/oda kartı denenebilir.
const SAMPLE_ITEMS = [
  ['vehicle', 'Örnek Araç', 'vehicle.png'],
  ['chat_bubble', 'Örnek Sohbet Balonu', 'chat_bubble.png'],
  ['mic_wave', 'Örnek Mikrofon Dalgası', 'mic_wave.png'],
  ['frame', 'Örnek Çerçeve', 'frame.png'],
  ['mini_card', 'Örnek Profil Kartı', 'profile_card.png'],
  ['room_card', 'Örnek Oda Kartı', 'room_card.png'],
];
const SAMPLE_DIR = new URL('../samples/', import.meta.url);
router.post('/store/samples', requireSuperAdmin, async (req, res) => {
  const made = [];
  for (const [category, name, file] of SAMPLE_ITEMS) {
    let item = (await query(`SELECT * FROM store_items WHERE category = $1 AND name = $2 AND is_active = TRUE LIMIT 1`, [category, name])).rows[0];
    if (!item) {
      const buf = fs.readFileSync(new URL(file, SAMPLE_DIR));
      const m = await query(
        `INSERT INTO media_files(kind, mime, ext, size_bytes, data, meta, created_by) VALUES('png','image/png','png',$1,$2,$3,$4) RETURNING id`,
        [buf.length, buf, JSON.stringify({ purpose: 'store_sample' }), req.user.id],
      );
      const url = `/media/${m.rows[0].id}.png`;
      const refId = category === 'frame' ? (await query(`INSERT INTO frames(name, image_url) VALUES($1,$2) RETURNING id`, [name, url])).rows[0].id : null;
      item = (await query(
        `INSERT INTO store_items(category, name, image_url, ref_id, price_coins, duration_days, for_sale) VALUES($1,$2,$3,$4,0,30,FALSE) RETURNING *`,
        [category, name, url, refId],
      )).rows[0];
    }
    const key = category === 'frame' && item.ref_id ? String(item.ref_id) : String(item.id);
    await tx(async (c) => {
      // Aynı türdeki diğer öğeler çıkarılır, örnek takılır (deneme için).
      await c.query(`UPDATE inventory_items SET metadata = COALESCE(metadata, '{}'::jsonb) || '{"equipped": false}'::jsonb WHERE user_id = $1 AND item_type = $2`, [req.user.id, category]);
      const ex = (await c.query(
        `SELECT id FROM inventory_items WHERE user_id = $1 AND item_type = $2 AND item_key = $3 AND is_active = TRUE AND (expires_at IS NULL OR expires_at > NOW()) LIMIT 1`,
        [req.user.id, category, key],
      )).rows[0];
      if (ex) {
        await c.query(`UPDATE inventory_items SET metadata = COALESCE(metadata, '{}'::jsonb) || '{"equipped": true}'::jsonb WHERE id = $1`, [ex.id]);
      } else {
        await c.query(
          `INSERT INTO inventory_items(user_id, item_type, item_key, item_name, expires_at, metadata) VALUES($1,$2,$3,$4, NOW() + INTERVAL '30 days', $5)`,
          [req.user.id, category, key, name, JSON.stringify({ assetUrl: item.image_url, storeItemId: item.id, grantedBy: req.user.id, equipped: true })],
        );
      }
    });
    made.push(name);
  }
  res.status(201).json({ ok: true, items: made });
  announceUserChange(req.user.id);
});

// Hazır hediye / çerçeve paketi (TR-Live-paket-N.zip): telefondan doğrudan yüklenir ve hemen uygulanır.
let packBusy = false;
router.post('/asset-pack', requireSuperAdmin, express.raw({ type: () => true, limit: MEDIA_MAX_BYTES }), async (req, res) => {
  const buf = req.body;
  if (!Buffer.isBuffer(buf) || !buf.length) throw fail('Dosya gönderilmedi.');
  if (packBusy) throw fail('Başka bir paket uygulanıyor, biraz sonra tekrar deneyin.', 409);
  packBusy = true;
  try {
    let results;
    try {
      results = await applyPackZip(buf);
    } catch (e) {
      throw fail(`Paket okunamadı: ${e.message}`);
    }
    if (!results.length) throw fail('Bu zip içinde hediye / çerçeve dosyası yok (TR-Live-paket-N.zip olmalı).');
    const count = (s) => results.filter((r) => r.status === s).length;
    res.json({ ok: true, added: count('added'), updated: count('updated'), same: count('same'), deleted: count('deleted'), failed: count('error') + count('incomplete'), results });
  } finally {
    packBusy = false;
  }
});
// Sunucu (Oracle kurulumu): güncelleme / kurulum kayıtları ve "şimdi güncelle" isteği.
// Kayıtlar sunucudaki /opt/trlive/state klasöründen gelir (compose ile /srv/state'e bağlı); yoksa boş döner.
const STATE_DIR = '/srv/state';
function tailFile(name, lines) {
  try {
    return fs.readFileSync(`${STATE_DIR}/${name}`, 'utf8').split('\n').slice(-lines).join('\n').trim();
  } catch {
    return null;
  }
}
router.get('/server/status', requireSuperAdmin, async (_req, res) => {
  let gitToken = false;
  try { gitToken = fs.statSync(`${STATE_DIR}/git-token`).size > 0; } catch { /* yok */ }
  res.json({
    serverVersion: SERVER_VERSION,
    gitToken,
    available: (() => {
      try { fs.accessSync(`${STATE_DIR}/update`, fs.constants.W_OK); return true; } catch { return false; }
    })(),
    updateLog: tailFile('update.log', 25),
    installLog: tailFile('install.log', 40),
  });
});
// Depo gizliyse sunucunun güncellemeyi indirebilmesi için GitHub erişim anahtarı (yalnızca okuma izinli).
// Anahtar yalnızca sunucuya yazılır; geri okunamaz (dosya yalnız yazılabilir). Boş gönderilirse silinir.
router.post('/server/git-token', requireSuperAdmin, async (req, res) => {
  const token = String(req.body?.token ?? '').trim();
  if (token && !/^(github_pat_|ghp_)[A-Za-z0-9_]{20,250}$/.test(token)) {
    throw fail('Anahtar geçersiz görünüyor. GitHub anahtarı "github_pat_" ya da "ghp_" ile başlar.');
  }
  try {
    fs.writeFileSync(`${STATE_DIR}/git-token`, token ? `${token}\n` : '', { mode: 0o600 });
  } catch {
    throw fail('Sunucu anahtarı kaydedemedi (sunucu henüz bu sürüme güncellenmemiş olabilir).');
  }
  // Hemen dene.
  try { fs.writeFileSync(`${STATE_DIR}/update`, `${new Date().toISOString()}\n`); } catch { /* sonraki kontrolde */ }
  res.json({ ok: true, saved: Boolean(token) });
});
router.post('/server/update', requireSuperAdmin, async (_req, res) => {
  try {
    fs.writeFileSync(`${STATE_DIR}/update`, `${new Date().toISOString()}\n`);
  } catch {
    throw fail('Sunucu bu isteği alamıyor (istek dosyası yazılamıyor). Birkaç dakika sonra tekrar deneyin.');
  }
  res.json({ ok: true });
});
router.get('/asset-pack/status', requireSuperAdmin, async (_req, res) => {
  res.json({ serverVersion: SERVER_VERSION, ...(await packStatus()) });
});
router.post('/media', requireSuperAdmin, express.raw({ type: () => true, limit: MEDIA_MAX_BYTES }), async (req, res) => {
  const buf = req.body;
  if (!Buffer.isBuffer(buf) || !buf.length) throw fail('Dosya gönderilmedi.');
  const d = detectMedia(buf);
  // alpha: 'auto' (varsayılan) sunucu anlar; 'left' / 'right' elle seçim.
  const alpha = ['left', 'right'].includes(req.query.alpha) ? req.query.alpha : 'auto';
  let data = buf; let note = null; let iconPng = null;
  if (d.kind === 'mp4') {
    let prepared = null;
    try {
      prepared = await prepareMp4(buf, alpha, { frame: req.query.purpose === 'frame' });
    } catch (e) {
      console.error('Video hazırlanamadı:', e.message);
    }
    if (prepared) {
      data = ensureVapc(prepared.buf, prepared.alpha).buf;
      iconPng = prepared.icon;
      note = prepared.converted
        ? (prepared.scene ? 'Arka planlı video tam ekran (kenarları yumuşak) şeffaf mp4\'e çevrildi.' : 'Siyah arka plan şeffaf yapıldı.')
        : `Şeffaf mp4 (maske ${prepared.alpha === 'right' ? 'sağda' : 'solda'}).`;
    } else {
      const r = ensureVapc(buf, alpha === 'right' ? 'right' : 'left');
      data = r.buf;
      note = r.injected ? 'Şeffaflık ayarı eklendi.' : 'Dosyada şeffaflık ayarı zaten vardı.';
    }
  }
  const save = (kind, mime, ext, bytes, meta) => query(
    `INSERT INTO media_files(kind, mime, ext, size_bytes, data, meta, created_by) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
    [kind, mime, ext, bytes.length, bytes, JSON.stringify(meta ?? {}), req.user.id],
  );
  const ins = await save(d.kind, mimeFor(d.ext), d.ext, data, d.meta);
  const url = `/media/${ins.rows[0].id}.${d.ext}`;
  // Küçük resim (hediye ikonu): videodan otomatik; görsel dosyalarda dosyanın kendisi.
  let iconUrl = null;
  if (iconPng) iconUrl = `/media/${(await save('png', 'image/png', 'png', iconPng, { purpose: 'auto_icon' })).rows[0].id}.png`;
  else if (['png', 'jpg', 'webp', 'gif'].includes(d.kind)) iconUrl = url;
  const format = { mp4: 'mp4', svga: 'svga', json: 'lottie', webp: 'webp', gif: 'gif', png: 'png', jpg: 'png' }[d.kind];
  res.status(201).json({ url, kind: d.kind, format, size: data.length, note, iconUrl });
});
// İkon verilmediyse animasyondan otomatik: görsel dosyada kendisi, yüklenmiş mp4'te ortalardaki kare.
async function autoIcon(animationUrl, userId) {
  if (!animationUrl) return null;
  if (/\.(png|jpe?g|webp|gif)(\?|$)/i.test(animationUrl)) return animationUrl;
  const m = /^\/media\/([0-9a-f-]{36})\.mp4$/i.exec(animationUrl);
  if (!m) return null;
  try {
    const row = (await query('SELECT data FROM media_files WHERE id = $1', [m[1]])).rows[0];
    if (!row) return null;
    const p = await prepareMp4(row.data, 'auto', { iconOnly: true });
    if (!p?.icon) return null;
    const ins = await query(
      `INSERT INTO media_files(kind, mime, ext, size_bytes, data, meta, created_by) VALUES('png','image/png','png',$1,$2,$3,$4) RETURNING id`,
      [p.icon.length, p.icon, JSON.stringify({ purpose: 'auto_icon' }), userId],
    );
    return `/media/${ins.rows[0].id}.png`;
  } catch (e) {
    console.error('Otomatik ikon yapılamadı:', e.message);
    return null;
  }
}
// Küçük resmi olmayan hediyelere animasyondan otomatik küçük resim yapar.
// Her çağrıda en fazla 3 hediye (istek kısa sürsün); uygulama "kalan" bitene kadar tekrar çağırır.
let filling = false;
router.post('/gifts/fill-icons', requireSuperAdmin, async (req, res) => {
  if (filling) throw fail('Küçük resimler zaten hazırlanıyor, biraz bekleyin.', 409);
  filling = true;
  try {
  const rows = (await query(`SELECT id, animation_url FROM gifts WHERE (icon_url IS NULL OR icon_url = '') AND animation_url IS NOT NULL ORDER BY id LIMIT 3 OFFSET $1`,
    [Math.min(10000, Math.max(0, Number(req.body?.skip) | 0))])).rows;
  let done = 0;
  for (const g of rows) {
    const icon = await autoIcon(g.animation_url, req.user.id);
    if (icon) {
      await query(`UPDATE gifts SET icon_url = $2 WHERE id = $1`, [g.id, icon]);
      done++;
    }
  }
  const left = (await query(`SELECT COUNT(*)::int AS n FROM gifts WHERE (icon_url IS NULL OR icon_url = '') AND animation_url IS NOT NULL`)).rows[0].n;
  res.json({ ok: true, total: rows.length, done, failed: rows.length - done, left });
  } finally {
    filling = false;
  }
});
router.post('/gifts', requireSuperAdmin, async (req, res) => {
  // Önce doğrulama (hatalıysa boşuna küçük resim üretilmesin).
  const name = text(req.body?.name, 'Ad', { min: 2, max: 80, required: true });
  const price = bigAmount(req.body?.coinPrice, 'Fiyat').toString();
  const animUrl = assetUrl(req.body?.animationUrl, 'Animasyon adresi');
  const format = oneOf(req.body?.animationFormat ?? guessFormat(req.body?.animationUrl), ['lottie', 'svga', 'mp4', 'webp', 'gif', 'png'], 'Animasyon biçimi');
  const category = oneOf(req.body?.category ?? 'popular', ['event', 'popular', 'private', 'vip', 'lucky', 'cp'], 'Hediye sekmesi');
  const playMode = oneOf(req.body?.playMode ?? 'full', ['full', 'seat'], 'Oynatma yeri');
  const iconUrl = assetUrl(req.body?.iconUrl, 'İkon adresi') ?? await autoIcon(animUrl, req.user.id);
  const r = await query(
    `INSERT INTO gifts(name, coin_price, icon_url, animation_url, animation_format, has_alpha, category, play_mode) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
    [name, price, iconUrl, animUrl, format, req.body?.hasAlpha !== false, category, playMode],
  );
  res.status(201).json({ id: r.rows[0].id });
});
router.post('/frames', requireSuperAdmin, async (req, res) => {
  const r = await query(`INSERT INTO frames(name, image_url) VALUES($1,$2) RETURNING id`, [
    text(req.body?.name, 'Ad', { min: 2, max: 100, required: true }), assetUrl(req.body?.imageUrl, 'Görsel adresi') ?? (() => { throw fail('Görsel adresi gerekli.'); })()]);
  res.status(201).json({ id: r.rows[0].id });
});
router.post('/entrance-effects', requireSuperAdmin, async (req, res) => {
  const r = await query(`INSERT INTO entrance_effects(name, animation_url, duration_ms) VALUES($1,$2,$3) RETURNING id`, [
    text(req.body?.name, 'Ad', { min: 2, max: 100, required: true }),
    assetUrl(req.body?.animationUrl, 'Animasyon adresi') ?? (() => { throw fail('Animasyon adresi gerekli.'); })(),
    req.body?.durationMs === undefined ? 4000 : positiveInt(req.body.durationMs, 'Süre', 20000)]);
  res.status(201).json({ id: r.rows[0].id });
});
const STORE_CATS = ['frame', 'chat_bubble', 'entrance_effect', 'mini_card', 'mic_wave', 'vehicle', 'badge', 'room_card'];
// Yönetimden ayrı ayrı verilebilen WIP öğeleri (kategori → ad eki).
const WIP_GRANT_KIND = { frame: 'çerçevesi', chat_bubble: 'sohbet balonu', badge: 'rozeti', entrance_effect: 'giriş efekti', vehicle: 'aracı' };
router.get('/store/items', requireSuperAdmin, async (_req, res) => {
  const r = await query(`SELECT * FROM store_items ORDER BY is_active DESC, category, sort_order, created_at DESC LIMIT 500`);
  res.json({ items: r.rows.map((x) => ({ id: x.id, category: x.category, name: x.name, imageUrl: x.image_url, priceCoins: String(x.price_coins), durationDays: x.duration_days, isActive: x.is_active, forSale: x.for_sale })) });
});
router.post('/store/items', requireSuperAdmin, async (req, res) => {
  const category = oneOf(req.body?.category, STORE_CATS, 'Kategori');
  const name = text(req.body?.name, 'Ad', { min: 2, max: 100, required: true });
  const imageUrl = assetUrl(req.body?.imageUrl, 'Görsel adresi') ?? (() => { throw fail('Görsel adresi gerekli.'); })();
  const price = bigAmount(req.body?.priceCoins ?? 0, 'Fiyat');
  const days = req.body?.durationDays === undefined ? 14 : positiveInt(req.body.durationDays, 'Süre (gün)', 3650);
  // Çerçeve ve giriş efekti: mevcut kataloğa da eklenir (profilde/odada aynı kodla gösterilir).
  let refId = null;
  if (category === 'frame') refId = (await query(`INSERT INTO frames(name, image_url) VALUES($1,$2) RETURNING id`, [name, imageUrl])).rows[0].id;
  if (category === 'entrance_effect') refId = (await query(`INSERT INTO entrance_effects(name, animation_url, duration_ms) VALUES($1,$2,4000) RETURNING id`, [name, imageUrl])).rows[0].id;
  const r = await query(
    `INSERT INTO store_items(category, name, image_url, ref_id, price_coins, duration_days, for_sale) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
    [category, name, imageUrl, refId, price.toString(), days, req.body?.forSale !== false && category !== 'badge'],
  );
  res.status(201).json({ id: r.rows[0].id });
});
router.post('/store/items/:id/active', requireSuperAdmin, async (req, res) => {
  if (typeof req.body?.isActive !== 'boolean') throw fail('isActive true/false olmalı.');
  const r = await query(`UPDATE store_items SET is_active = $2 WHERE id = $1 RETURNING id`, [uuid(req.params.id, 'Kimlik'), req.body.isActive]);
  if (!r.rowCount) throw fail('Ürün bulunamadı.', 404);
  res.json({ ok: true });
});
// Silme: geçmişte kullanılmışsa (satın alma/hediye kaydı) kayıtlar bozulmasın diye gizlenir, aksi halde tamamen silinir.
async function removeOrHide(res, table, id, usedBy) {
  try {
    const r = await query(`DELETE FROM ${table} WHERE id = $1 RETURNING id`, [id]);
    if (!r.rowCount) throw fail('Kayıt bulunamadı.', 404);
    res.json({ ok: true, hidden: false });
  } catch (e) {
    if (e?.code !== '23503') throw e;
    await query(`UPDATE ${table} SET is_active = FALSE WHERE id = $1`, [id]);
    res.json({ ok: true, hidden: true, note: usedBy });
  }
}
router.delete('/gifts/:id', requireSuperAdmin, async (req, res) => removeOrHide(res, 'gifts', uuid(req.params.id, 'Kimlik'), 'Geçmişte gönderildiği için silinmedi, gizlendi.'));
router.delete('/store/items/:id', requireSuperAdmin, async (req, res) => removeOrHide(res, 'store_items', uuid(req.params.id, 'Kimlik'), 'Geçmişte alındığı için silinmedi, gizlendi.'));
router.delete('/frames/:id', requireSuperAdmin, async (req, res) => removeOrHide(res, 'frames', uuid(req.params.id, 'Kimlik'), 'Kullanıcılarda olduğu için silinmedi, gizlendi.'));
router.get('/catalog', requireSuperAdmin, async (_req, res) => {
  const g = await query(`SELECT id, name, coin_price, icon_url, animation_url, animation_format, category, play_mode, is_active FROM gifts ORDER BY is_active DESC, coin_price DESC, name`);
  const f = await query(`SELECT id, name, image_url, is_active FROM frames ORDER BY is_active DESC, name`);
  res.json({
    gifts: g.rows.map((r) => ({ id: r.id, name: r.name, coinPrice: String(r.coin_price), iconUrl: r.icon_url, animationUrl: r.animation_url, animationFormat: r.animation_format, category: r.category, playMode: r.play_mode ?? 'full', isActive: r.is_active })),
    frames: f.rows.map((r) => ({ id: r.id, name: r.name, imageUrl: r.image_url, isActive: r.is_active })),
  });
});
const TOGGLE_TABLES = { gifts: 'gifts', frames: 'frames', 'entrance-effects': 'entrance_effects', music: 'music_tracks' };
router.post('/catalog/:kind/:id/active', requireSuperAdmin, async (req, res) => {
  const table = TOGGLE_TABLES[req.params.kind];
  if (!table) throw fail('Geçersiz katalog türü.', 404);
  if (typeof req.body?.isActive !== 'boolean') throw fail('isActive true/false olmalı.');
  const r = await query(`UPDATE ${table} SET is_active = $2 WHERE id = $1 RETURNING id`, [uuid(req.params.id, 'Kimlik'), req.body.isActive]);
  if (!r.rowCount) throw fail('Öğe bulunamadı.', 404);
  res.json({ ok: true });
});

// Ad / fiyat düzenleme (hediye, çerçeve, mağaza ürünü). Gönderilmeyen alan değişmez.
const GIFT_TABS = ['event', 'popular', 'private', 'vip', 'lucky', 'cp'];
router.post('/gifts/:id/edit', requireSuperAdmin, async (req, res) => {
  const id = uuid(req.params.id, 'Kimlik');
  const b = req.body ?? {};
  const name = b.name === undefined ? null : text(b.name, 'Ad', { min: 2, max: 80, required: true });
  const price = b.coinPrice === undefined ? null : bigAmount(b.coinPrice, 'Fiyat').toString();
  const category = b.category === undefined ? null : oneOf(b.category, GIFT_TABS, 'Hediye sekmesi');
  const playMode = b.playMode === undefined ? null : oneOf(b.playMode, ['full', 'seat'], 'Oynatma yeri');
  const r = await query(
    `UPDATE gifts SET name = COALESCE($2, name), coin_price = COALESCE($3::bigint, coin_price), category = COALESCE($4, category),
       play_mode = COALESCE($5, play_mode) WHERE id = $1 RETURNING id`,
    [id, name, price, category, playMode],
  );
  if (!r.rowCount) throw fail('Hediye bulunamadı.', 404);
  res.json({ ok: true });
});
router.post('/frames/:id/edit', requireSuperAdmin, async (req, res) => {
  const id = uuid(req.params.id, 'Kimlik');
  const name = text(req.body?.name, 'Ad', { min: 2, max: 100, required: true });
  const r = await tx(async (c) => {
    const u = await c.query(`UPDATE frames SET name = $2 WHERE id = $1 RETURNING id`, [id, name]);
    if (u.rowCount) await c.query(`UPDATE store_items SET name = $2 WHERE category = 'frame' AND ref_id = $1`, [id, name]);
    return u;
  });
  if (!r.rowCount) throw fail('Çerçeve bulunamadı.', 404);
  res.json({ ok: true });
});
router.post('/store/items/:id/edit', requireSuperAdmin, async (req, res) => {
  const id = uuid(req.params.id, 'Kimlik');
  const b = req.body ?? {};
  const name = b.name === undefined ? null : text(b.name, 'Ad', { min: 2, max: 100, required: true });
  // Mağaza ürününün fiyatı 0 olabilir (yalnızca yöneticinin verdiği ürünler).
  const price = b.priceCoins === undefined ? null
    : (/^0+$/.test(String(b.priceCoins).trim()) ? '0' : bigAmount(b.priceCoins, 'Fiyat').toString());
  const days = b.durationDays === undefined ? null : positiveInt(b.durationDays, 'Süre (gün)', 3650);
  if (b.forSale !== undefined && typeof b.forSale !== 'boolean') throw fail('forSale true/false olmalı.');
  const forSale = b.forSale === undefined ? null : b.forSale;
  const r = await tx(async (c) => {
    const u = await c.query(
      `UPDATE store_items SET name = COALESCE($2, name), price_coins = COALESCE($3::bigint, price_coins),
         duration_days = COALESCE($4::int, duration_days),
         for_sale = COALESCE($5::boolean, for_sale) AND category <> 'badge' AND COALESCE($3::bigint, price_coins) > 0
       WHERE id = $1 RETURNING category, ref_id`,
      [id, name, price, days, forSale],
    );
    const it = u.rows[0];
    if (it && name && it.ref_id) {
      if (it.category === 'frame') await c.query(`UPDATE frames SET name = $2 WHERE id = $1`, [it.ref_id, name]);
      if (it.category === 'entrance_effect') await c.query(`UPDATE entrance_effects SET name = $2 WHERE id = $1`, [it.ref_id, name]);
    }
    return u;
  });
  if (!r.rowCount) throw fail('Ürün bulunamadı.', 404);
  res.json({ ok: true });
});

// ---------------- Bayi (yalnızca yönetici) ----------------
router.get('/dealers', requireSuperAdmin, async (req, res) => {
  const r = await query(
    `SELECT d.*, u.username AS owner_username FROM dealer_accounts d LEFT JOIN users u ON u.id = d.owner_user_id ORDER BY d.created_at DESC LIMIT 200`,
  );
  res.json({ dealers: r.rows.map((d) => ({
    id: d.id, name: d.name, ownerUserId: d.owner_user_id, ownerUsername: d.owner_username,
    coinBalance: String(d.coin_balance), commissionBps: d.commission_bps, isActive: d.is_active,
  })) });
});

router.post('/dealers', requireSuperAdmin, async (req, res) => {
  const bps = req.body?.commissionBps === undefined ? 0 : Number(req.body.commissionBps);
  if (!Number.isInteger(bps) || bps < 0 || bps > 10000) throw fail('Komisyon 0-10000 (baz puan) arasında olmalı.');
  const ownerId = req.body?.ownerUserId ? uuid(req.body.ownerUserId, 'Sahip') : null;
  if (ownerId) await assertUser(ownerId);
  const r = await query(
    `INSERT INTO dealer_accounts(name, owner_user_id, commission_bps) VALUES($1,$2,$3) RETURNING id, name`,
    [text(req.body?.name, 'Bayi adı', { min: 2, max: 100, required: true }), ownerId, bps],
  );
  res.status(201).json({ dealer: r.rows[0] });
});

router.post('/dealers/:dealerId/coins', requireSuperAdmin, async (req, res) => {
  const dealerId = uuid(req.params.dealerId, 'Bayi');
  const amount = bigAmount(req.body?.amount, 'Bayi Coin miktarı');
  const result = await tx(async (c) => {
    const dealer = (await c.query(`SELECT * FROM dealer_accounts WHERE id = $1 FOR UPDATE`, [dealerId])).rows[0];
    if (!dealer) throw fail('Bayi bulunamadı.', 404);
    const before = BigInt(dealer.coin_balance);
    const balance = before + amount;
    await c.query(`UPDATE dealer_accounts SET coin_balance = $1 WHERE id = $2`, [balance.toString(), dealer.id]);
    await c.query(
      `INSERT INTO dealer_transactions(dealer_id, admin_id, type, coin_amount, description) VALUES($1,$2,'credit',$3,$4)`,
      [dealer.id, req.user.id, amount.toString(), text(req.body?.description, 'Açıklama', { max: 200 }) || 'Admin bayi Coin yükleme'],
    );
    await c.query(
      `INSERT INTO financial_audit_logs(admin_id, action, reference_type, reference_id, amount_coins, balance_before, balance_after)
       VALUES($1,'dealer_credit','dealer',$2,$3,$4,$5)`,
      [req.user.id, dealer.id, amount.toString(), before.toString(), balance.toString()],
    );
    return { balance: balance.toString() };
  });
  res.json(result);
});

router.post('/dealers/:dealerId/sell', requireSuperAdmin, async (req, res) => {
  const result = await tx((c) => dealerSell(c, {
    dealerId: uuid(req.params.dealerId, 'Bayi'), userId: uuid(req.body?.userId, 'Kullanıcı'),
    coins: bigAmount(req.body?.amount, 'Satış Coin miktarı'), actorId: req.user.id, description: text(req.body?.description, 'Açıklama', { max: 200 }),
  }));
  res.json(result);
});

// ---------------- Ajans ve yayıncı ----------------
router.get('/agencies', async (req, res) => {
  const status = req.query.status ? oneOf(String(req.query.status), ['pending', 'active', 'suspended', 'rejected'], 'Durum') : null;
  const r = await query(
    `SELECT a.*, u.username AS owner_username, (SELECT COUNT(*)::int FROM broadcasters b WHERE b.agency_id = a.id) AS broadcaster_count
     FROM agencies a JOIN users u ON u.id = a.owner_id WHERE ($1::text IS NULL OR a.status = $1) ORDER BY a.created_at DESC LIMIT 200`,
    [status],
  );
  res.json({ agencies: r.rows.map((a) => ({
    id: a.id, name: a.name, ownerId: a.owner_id, ownerUsername: a.owner_username, status: a.status,
    commissionBps: a.commission_bps, overrideBps: a.commission_override_bps, agencyCode: a.agency_code, broadcasterCount: a.broadcaster_count, createdAt: a.created_at,
  })) });
});

// Yönetici bir kullanıcıyı (ID / kullanıcı adı ile seçilir) ajans sahibi yapar; ajans doğrudan aktif açılır.
router.post('/agencies', requireSuperAdmin, async (req, res) => {
  const userId = uuid(req.body?.userId, 'Kullanıcı');
  const name = cleanPublic(text(req.body?.name, 'Ajans adı', { min: 3, max: 60, required: true }), 'Ajans adı');
  const description = text(req.body?.description, 'Açıklama', { max: 500 });
  let agency;
  try {
    agency = await tx(async (c) => {
      const u = (await c.query(`SELECT id, account_status FROM users WHERE id = $1 FOR UPDATE`, [userId])).rows[0];
      if (!u || u.account_status !== 'active') throw fail('Kullanıcı bulunamadı veya hesabı aktif değil.', 404);
      if ((await c.query(`SELECT 1 FROM agencies WHERE owner_id = $1 AND status <> 'rejected'`, [userId])).rowCount) {
        throw fail('Bu kullanıcının zaten bir ajansı var.', 409);
      }
      const row = (await c.query(
        `INSERT INTO agencies(name, owner_id, description, status, approved_by, approved_at) VALUES($1,$2,$3,'active',$4,NOW()) RETURNING *`,
        [name, userId, description, req.user.id],
      )).rows[0];
      await c.query(
        `INSERT INTO financial_audit_logs(admin_id, user_id, action, reference_type, reference_id, metadata) VALUES($1,$2,'agency_create','agency',$3,$4)`,
        [req.user.id, userId, row.id, JSON.stringify({ name })],
      );
      return row;
    });
  } catch (error) {
    if (error.code === '23505') throw fail(error.constraint === 'idx_agencies_owner' ? 'Bu kullanıcının zaten bir ajansı var.' : 'Bu ajans adı kullanılıyor.', 409);
    throw error;
  }
  const code = await ensureAgencyCode(agency.id);
  hub.sendToUser(userId, { type: 'agency_created', agency: { id: agency.id, name: agency.name } });
  res.status(201).json({ agency: { id: agency.id, name: agency.name, status: agency.status, agencyCode: code } });
});

// Komisyon para etkisi taşıdığı için yalnızca yönetici.
router.post('/agencies/:agencyId/status', requireSuperAdmin, async (req, res) => {
  const agencyId = uuid(req.params.agencyId, 'Ajans');
  const status = oneOf(req.body?.status, ['active', 'suspended', 'rejected'], 'Durum');
  let bps = null;
  if (req.body?.commissionBps !== undefined) {
    bps = Number(req.body.commissionBps);
    if (!Number.isInteger(bps) || bps < 0 || bps > 10000) throw fail('Komisyon 0-10000 (baz puan) arasında olmalı.');
  }
  const r = await query(
    `UPDATE agencies SET status = $2::text, commission_bps = COALESCE($3, commission_bps),
       approved_by = CASE WHEN $2::text = 'active' THEN $4::uuid ELSE approved_by END,
       approved_at = CASE WHEN $2::text = 'active' THEN NOW() ELSE approved_at END
     WHERE id = $1 RETURNING id, status, commission_bps`,
    [agencyId, status, bps, req.user.id],
  );
  if (!r.rowCount) throw fail('Ajans bulunamadı.', 404);
  if (status === 'active') await ensureAgencyCode(agencyId);
  await query(
    `INSERT INTO financial_audit_logs(admin_id, action, reference_type, reference_id, metadata) VALUES($1,'agency_status','agency',$2,$3)`,
    [req.user.id, agencyId, JSON.stringify({ status, commissionBps: r.rows[0].commission_bps })],
  );
  res.json({ agency: r.rows[0] });
});

router.get('/broadcasters', async (req, res) => {
  const status = req.query.status ? oneOf(String(req.query.status), ['pending', 'approved', 'rejected', 'suspended'], 'Durum') : null;
  const r = await query(
    `SELECT b.user_id, b.status, b.applied_at, b.agency_id, u.username, u.display_name, a.name AS agency_name
     FROM broadcasters b JOIN users u ON u.id = b.user_id LEFT JOIN agencies a ON a.id = b.agency_id
     WHERE ($1::text IS NULL OR b.status = $1) ORDER BY b.applied_at DESC LIMIT 200`,
    [status],
  );
  res.json({ broadcasters: r.rows.map((b) => ({
    userId: b.user_id, username: b.username, displayName: b.display_name, status: b.status, appliedAt: b.applied_at,
    agencyId: b.agency_id, agencyName: b.agency_name,
  })) });
});

router.post('/broadcasters/:userId/status', async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const status = oneOf(req.body?.status, ['approved', 'rejected', 'suspended'], 'Durum');
  const r = await query(
    `UPDATE broadcasters SET status = $2::text,
       approved_by = CASE WHEN $2::text = 'approved' THEN $3::uuid ELSE approved_by END,
       approved_at = CASE WHEN $2::text = 'approved' THEN NOW() ELSE approved_at END,
       agency_id = CASE WHEN $2::text IN ('rejected','suspended') THEN NULL ELSE agency_id END
     WHERE user_id = $1 RETURNING user_id, status`,
    [userId, status, req.user.id],
  );
  if (!r.rowCount) throw fail('Yayıncı başvurusu bulunamadı.', 404);
  await query(
    `INSERT INTO financial_audit_logs(admin_id, user_id, action, reference_type, metadata) VALUES($1,$2,'broadcaster_status','broadcaster',$3)`,
    [req.user.id, userId, JSON.stringify({ status })],
  );
  res.json({ broadcaster: r.rows[0] });
});

// ---------------- Ajans ayarları, etkinlikler, dönem kapatma, KYC ----------------
router.get('/agency-config', async (req, res) => {
  res.json({ config: configJson(await loadConfig()) });
});

router.put('/agency-config', requireSuperAdmin, async (req, res) => {
  const v = validateAgencyConfig(req.body);
  await tx(async (c) => {
    if (v.settings) {
      const m = { cycle: 'cycle', penaltyBps: 'penalty_bps', requireOfficialEvents: 'require_official_events', minEventCount: 'min_event_count', currency: 'currency' };
      for (const [k, col] of Object.entries(m)) {
        if (v.settings[k] !== undefined) await c.query(`UPDATE agency_settings SET ${col} = $1, updated_at = NOW() WHERE id = 1`, [v.settings[k]]);
      }
    }
    if (v.salaryTiers) {
      await c.query(`DELETE FROM host_salary_tiers`);
      for (const t of v.salaryTiers) {
        await c.query(`INSERT INTO host_salary_tiers(level, required_hours, required_diamonds, salary_cents) VALUES($1,$2,$3,$4)`, [t.level, t.hours, t.diamonds.toString(), t.salaryCents.toString()]);
      }
    }
    if (v.commissionTiers) {
      await c.query(`DELETE FROM agency_commission_tiers`);
      for (const t of v.commissionTiers) {
        await c.query(`INSERT INTO agency_commission_tiers(level, min_team_diamonds, commission_bps) VALUES($1,$2,$3)`, [t.level, t.minDiamonds.toString(), t.bps]);
      }
    }
    await c.query(`INSERT INTO financial_audit_logs(admin_id, action, reference_type, metadata) VALUES($1,'agency_config_update','agency_config',$2)`, [req.user.id, JSON.stringify(Object.keys(v))]);
  });
  res.json({ config: configJson(await loadConfig()) });
});

router.post('/agencies/:agencyId/commission-override', requireSuperAdmin, async (req, res) => {
  const agencyId = uuid(req.params.agencyId, 'Ajans');
  let bps = req.body?.bps;
  if (bps !== null) {
    if (!Number.isInteger(bps) || bps < 0 || bps > 10000) throw fail('Oran 0-10000 (baz puan) olmalı veya null.');
  }
  const r = await query(`UPDATE agencies SET commission_override_bps = $2 WHERE id = $1 RETURNING id, commission_override_bps`, [agencyId, bps]);
  if (!r.rowCount) throw fail('Ajans bulunamadı.', 404);
  await query(`INSERT INTO financial_audit_logs(admin_id, action, reference_type, reference_id, metadata) VALUES($1,'agency_commission_override','agency',$2,$3)`, [req.user.id, agencyId, JSON.stringify({ bps })]);
  res.json({ ok: true, overrideBps: r.rows[0].commission_override_bps });
});

router.post('/broadcasters/:userId/contract', requireSuperAdmin, async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const tier = req.body?.tier === null ? null : positiveInt(req.body?.tier, 'Kademe', 10);
  const r = await query(`UPDATE broadcasters SET contract_tier = $2 WHERE user_id = $1 RETURNING user_id`, [userId, tier]);
  if (!r.rowCount) throw fail('Yayıncı bulunamadı.', 404);
  res.json({ ok: true, tier });
});

router.post('/events', async (req, res) => {
  const title = text(req.body?.title, 'Başlık', { min: 3, max: 120, required: true });
  const startsAt = new Date(req.body?.startsAt);
  if (Number.isNaN(startsAt.getTime())) throw fail('Başlangıç zamanı geçersiz.');
  const r = await query(`INSERT INTO official_events(title, starts_at, created_by) VALUES($1,$2,$3) RETURNING id, title, starts_at`, [title, startsAt.toISOString(), req.user.id]);
  res.status(201).json({ event: r.rows[0] });
});

router.get('/events', async (req, res) => {
  const r = await query(
    `SELECT e.id, e.title, e.starts_at, (SELECT COUNT(*)::int FROM official_event_attendance a WHERE a.event_id = e.id) AS attendees
     FROM official_events e ORDER BY e.starts_at DESC LIMIT 100`,
  );
  res.json({ events: r.rows.map((e) => ({ id: e.id, title: e.title, startsAt: e.starts_at, attendees: e.attendees })) });
});

router.post('/events/:id/attendance', async (req, res) => {
  const eventId = uuid(req.params.id, 'Etkinlik');
  const userIds = (Array.isArray(req.body?.userIds) ? req.body.userIds : []).slice(0, 200).map((x) => uuid(x, 'Kullanıcı'));
  if (!userIds.length) throw fail('En az bir kullanıcı gerekli.');
  if (!(await query(`SELECT 1 FROM official_events WHERE id = $1`, [eventId])).rowCount) throw fail('Etkinlik bulunamadı.', 404);
  const r = await query(
    `INSERT INTO official_event_attendance(event_id, user_id, marked_by)
     SELECT $1, b.user_id, $3 FROM broadcasters b WHERE b.user_id = ANY($2::uuid[]) ON CONFLICT DO NOTHING`, [eventId, userIds, req.user.id],
  );
  res.json({ ok: true, added: r.rowCount });
});

// Dönemi kapat (hesap özetleri üretir). period boş ise bir önceki dönem.
router.post('/payouts/close', requireSuperAdmin, async (req, res) => {
  const cfg = await loadConfig();
  let key = req.body?.period;
  if (!key) key = previousPeriod(cfg.settings.cycle).key;
  try { parsePeriodKey(key); } catch (e) { throw fail(e.message); }
  const out = await closePeriod({ adminId: req.user.id, periodKey: key, force: req.body?.force === true });
  res.status(201).json(out);
});

router.get('/payouts', async (req, res) => {
  const r = await query(
    `SELECT p.id, p.period_key, p.cycle, p.starts_at, p.ends_at, p.closed_at,
       (SELECT COUNT(*)::int FROM host_statements h WHERE h.period_id = p.id) AS hosts,
       (SELECT COUNT(*)::int FROM host_statements h WHERE h.period_id = p.id AND h.status = 'pending') AS pending_hosts,
       (SELECT COALESCE(SUM(salary_cents),0) FROM host_statements h WHERE h.period_id = p.id) AS total_salary_cents,
       (SELECT COUNT(*)::int FROM agency_statements a WHERE a.period_id = p.id) AS agencies,
       (SELECT COUNT(*)::int FROM agency_statements a WHERE a.period_id = p.id AND a.status = 'pending') AS pending_agencies
     FROM payout_periods p ORDER BY p.starts_at DESC LIMIT 52`,
  );
  res.json({ periods: r.rows.map((p) => ({
    id: p.id, periodKey: p.period_key, cycle: p.cycle, startsAt: p.starts_at, endsAt: p.ends_at, closedAt: p.closed_at,
    hosts: p.hosts, pendingHosts: p.pending_hosts, totalSalaryCents: String(p.total_salary_cents), agencies: p.agencies, pendingAgencies: p.pending_agencies,
  })) });
});

router.get('/payouts/:id', async (req, res) => {
  const id = uuid(req.params.id, 'Dönem');
  const p = (await query(`SELECT * FROM payout_periods WHERE id = $1`, [id])).rows[0];
  if (!p) throw fail('Dönem bulunamadı.', 404);
  const hosts = (await query(
    `SELECT h.*, $2::text AS period_key, $3::timestamptz AS starts_at, $4::timestamptz AS ends_at, u.username, u.kyc_status
     FROM host_statements h JOIN users u ON u.id = h.user_id WHERE h.period_id = $1 ORDER BY h.salary_cents DESC`,
    [id, p.period_key, p.starts_at, p.ends_at],
  )).rows;
  const agencies = (await query(
    `SELECT s.*, $2::text AS period_key, $3::timestamptz AS starts_at, $4::timestamptz AS ends_at, a.name AS agency_name
     FROM agency_statements s JOIN agencies a ON a.id = s.agency_id WHERE s.period_id = $1 ORDER BY s.commission_diamonds DESC`,
    [id, p.period_key, p.starts_at, p.ends_at],
  )).rows;
  res.json({
    period: { id: p.id, periodKey: p.period_key, cycle: p.cycle, startsAt: p.starts_at, endsAt: p.ends_at, closedAt: p.closed_at },
    hostStatements: hosts.map((h) => ({ ...hostStatementJson(h), kycStatus: h.kyc_status })),
    agencyStatements: agencies.map(agencyStatementJson),
  });
});

// Ödeme platform dışında yapılır; burada yalnızca "ödendi" işaretlenir. Yayıncı için KYC onayı şarttır.
router.post('/statements/:kind/:id/pay', requireSuperAdmin, async (req, res) => {
  const kind = oneOf(req.params.kind, ['host', 'agency'], 'Tür');
  const id = uuid(req.params.id, 'Özet');
  await tx(async (c) => {
    if (kind === 'host') {
      const h = (await c.query(`SELECT h.*, u.kyc_status FROM host_statements h JOIN users u ON u.id = h.user_id WHERE h.id = $1 FOR UPDATE OF h`, [id])).rows[0];
      if (!h) throw fail('Özet bulunamadı.', 404);
      if (h.status !== 'pending') throw fail('Bu özet zaten işlenmiş.', 409);
      if (BigInt(h.salary_cents) > 0n && h.kyc_status !== 'approved') throw fail('Yayıncının kimlik doğrulaması (KYC) onaylı değil.', 409);
      await c.query(`UPDATE host_statements SET status = 'paid', paid_at = NOW(), paid_by = $2 WHERE id = $1`, [id, req.user.id]);
      await c.query(`INSERT INTO financial_audit_logs(admin_id, user_id, action, reference_type, reference_id, metadata) VALUES($1,$2,'host_salary_paid','host_statement',$3,$4)`,
        [req.user.id, h.user_id, id, JSON.stringify({ salaryCents: String(h.salary_cents) })]);
    } else {
      const a = (await c.query(`SELECT * FROM agency_statements WHERE id = $1 FOR UPDATE`, [id])).rows[0];
      if (!a) throw fail('Özet bulunamadı.', 404);
      if (a.status !== 'pending') throw fail('Bu özet zaten işlenmiş.', 409);
      await c.query(`UPDATE agency_statements SET status = 'paid', paid_at = NOW(), paid_by = $2 WHERE id = $1`, [id, req.user.id]);
      await c.query(`INSERT INTO financial_audit_logs(admin_id, action, reference_type, reference_id, amount_diamonds, metadata) VALUES($1,'agency_commission_paid','agency_statement',$2,$3,$4)`,
        [req.user.id, id, a.commission_diamonds, JSON.stringify({ agencyId: a.agency_id })]);
    }
  });
  res.json({ ok: true });
});

router.get('/kyc', async (req, res) => {
  const status = oneOf(String(req.query.status ?? 'pending'), ['pending', 'approved', 'rejected'], 'Durum');
  const r = await query(`SELECT id, username, display_name, kyc_status FROM users WHERE kyc_status = $1 ORDER BY username LIMIT 200`, [status]);
  res.json({ users: r.rows.map((u) => ({ id: u.id, username: u.username, displayName: u.display_name, kycStatus: u.kyc_status })) });
});

router.post('/users/:userId/kyc', requireSuperAdmin, async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const status = oneOf(req.body?.status, ['approved', 'rejected', 'none'], 'Durum');
  const r = await query(`UPDATE users SET kyc_status = $2 WHERE id = $1 RETURNING id`, [userId, status]);
  if (!r.rowCount) throw fail('Kullanıcı bulunamadı.', 404);
  await query(`INSERT INTO financial_audit_logs(admin_id, user_id, action, reference_type, metadata) VALUES($1,$2,'kyc_status','user',$3)`, [req.user.id, userId, JSON.stringify({ status })]);
  res.json({ ok: true, status });
});

router.get('/finance/audit', requireSuperAdmin, async (req, res) => {
  const limit = Math.max(1, Math.min(Math.floor(Number(req.query.limit)) || 100, 500));
  const userId = req.query.userId ? uuid(String(req.query.userId), 'Kullanıcı') : null;
  const r = await query(
    `SELECT * FROM financial_audit_logs WHERE ($1::uuid IS NULL OR user_id = $1) ORDER BY created_at DESC LIMIT $2`,
    [userId, limit],
  );
  res.json({ logs: r.rows });
});

// ---------------- Müzik kütüphanesi (yalnızca yönetici) ----------------
// Telif: yalnızca kullanım hakkına sahip olduğunuz parçaları ekleyin; lisans notu zorunludur.
router.post('/music/tracks', requireSuperAdmin, async (req, res) => {
  const url = httpsUrl(req.body?.url, 'Şarkı adresi');
  if (!url) throw fail('Şarkı adresi gerekli.');
  const r = await query(
    `INSERT INTO music_tracks(title, artist, url, cover_url, duration_ms, license_note, created_by) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
    [text(req.body?.title, 'Başlık', { min: 1, max: 120, required: true }), text(req.body?.artist, 'Sanatçı', { max: 120 }), url,
      httpsUrl(req.body?.coverUrl, 'Kapak adresi'), positiveInt(req.body?.durationMs, 'Süre (ms)', 7200000),
      text(req.body?.licenseNote, 'Lisans notu', { min: 3, max: 300, required: true }), req.user.id],
  );
  res.status(201).json({ id: r.rows[0].id });
});

router.get('/music/tracks', requireSuperAdmin, async (req, res) => {
  const r = await query(`SELECT id, title, artist, duration_ms, is_active, license_note FROM music_tracks ORDER BY created_at DESC LIMIT 200`);
  res.json({ tracks: r.rows.map((t) => ({ id: t.id, title: t.title, artist: t.artist, durationMs: t.duration_ms, isActive: t.is_active, licenseNote: t.license_note })) });
});

// ---------------- Şikâyetler (admin + support) ----------------
router.get('/reports', async (req, res) => {
  const status = oneOf(String(req.query.status ?? 'open'), ['open', 'resolved', 'dismissed'], 'Durum');
  const r = await query(
    `SELECT r.*, ru.username AS reporter_username, tu.username AS target_username FROM reports r
     JOIN users ru ON ru.id = r.reporter_id LEFT JOIN users tu ON tu.id = r.target_user_id
     WHERE r.status = $1 ORDER BY r.created_at DESC LIMIT 100`,
    [status],
  );
  res.json({ reports: r.rows.map((x) => ({
    id: x.id, kind: x.kind, reason: x.reason, details: x.details, status: x.status, createdAt: x.created_at,
    reporter: x.reporter_username, targetUserId: x.target_user_id, target: x.target_username, roomId: x.room_id, messageId: x.message_id,
  })) });
});

router.post('/reports/:id/resolve', async (req, res) => {
  const status = oneOf(req.body?.status, ['resolved', 'dismissed'], 'Durum');
  const r = await query(
    `UPDATE reports SET status = $2, resolved_by = $3, resolved_note = $4, resolved_at = NOW() WHERE id = $1 AND status = 'open' RETURNING id`,
    [uuid(req.params.id, 'Şikâyet'), status, req.user.id, text(req.body?.note, 'Not', { max: 300 })],
  );
  if (!r.rowCount) throw fail('Açık şikâyet bulunamadı.', 404);
  res.json({ ok: true });
});

// ---------------- Güvenlik duvarı (yalnızca yönetici) ----------------
router.get('/security/events', requireSuperAdmin, async (req, res) => {
  const limit = Math.max(1, Math.min(Math.floor(Number(req.query.limit)) || 100, 500));
  const type = req.query.type ? String(req.query.type).slice(0, 40) : null;
  const r = await query(
    `SELECT id, event_type, host(ip) AS ip, user_id, detail, created_at FROM security_events
     WHERE ($1::text IS NULL OR event_type = $1) ORDER BY created_at DESC LIMIT $2`,
    [type, limit],
  );
  res.json({ events: r.rows, stats: securityStats() });
});

router.get('/security/blocks', requireSuperAdmin, async (req, res) => {
  res.json({ blocks: listBans().map((b) => ({ ip: b.ip, reason: b.reason, until: b.until ? new Date(b.until).toISOString() : null })) });
});

router.post('/security/blocks', requireSuperAdmin, async (req, res) => {
  const ip = String(req.body?.ip ?? '').trim();
  if (!net.isIP(ip)) throw fail('Geçerli bir IP adresi girin.');
  const minutes = req.body?.minutes === undefined || req.body.minutes === null ? null : positiveInt(req.body.minutes, 'Süre (dk)', 525600);
  if (!(await banIpPersist(ip, minutes === null ? null : minutes * 60000, text(req.body?.reason, 'Neden', { max: 200 }) || 'Yönetici kararı', req.user.id))) {
    throw fail('Bu IP izin listesinde olduğu için engellenemez.', 409);
  }
  res.status(201).json({ ok: true });
});

router.delete('/security/blocks/:ip', requireSuperAdmin, async (req, res) => {
  const ip = String(req.params.ip);
  if (!net.isIP(ip)) throw fail('Geçerli bir IP adresi girin.');
  await unbanIp(ip);
  res.json({ ok: true });
});

// ---------- Haftalık etkinlikler (Çift, Kral/Kraliçe, Yıldız): açık/kapalı, yıldız hediyesi, ödüller, kurallar ----------
router.get('/weekly-events', requireSuperAdmin, async (_req, res) => {
  const r = await query(
    `SELECT c.*, g.name AS g_name, g.icon_url AS g_icon FROM weekly_event_config c LEFT JOIN gifts g ON g.id = c.gift_id ORDER BY c.kind`,
  );
  res.json({
    events: r.rows.map((c) => ({
      kind: c.kind, title: EVENT_TITLES[c.kind], enabled: c.enabled, isStar: isStar(c.kind),
      gift: c.gift_id ? { id: c.gift_id, name: c.g_name, iconUrl: c.g_icon } : null,
      rewards: c.rewards, rewardsView: rewardsView(c.rewards), rules: c.rules ?? '', defaultRules: defaultRules(c.kind),
    })),
  });
});

router.put('/weekly-events/:kind', requireSuperAdmin, async (req, res) => {
  const kind = String(req.params.kind);
  if (!EVENT_KINDS.includes(kind)) throw fail('Etkinlik bulunamadı.', 404);
  const sets = []; const values = [];
  const set = (col, v) => { values.push(v); sets.push(`${col} = $${values.length}`); };
  const b = req.body ?? {};
  if (b.enabled !== undefined) {
    if (typeof b.enabled !== 'boolean') throw fail('enabled true/false olmalı.');
    set('enabled', b.enabled);
  }
  if (b.giftId !== undefined) {
    if (!isStar(kind)) throw fail('Hediye yalnızca Yıldız etkinliklerinde seçilir.');
    if (b.giftId === null) set('gift_id', null);
    else {
      const gid = uuid(b.giftId, 'Hediye');
      if (!(await query(`SELECT 1 FROM gifts WHERE id = $1`, [gid])).rowCount) throw fail('Hediye bulunamadı.', 404);
      set('gift_id', gid);
    }
  }
  if (b.rewards !== undefined) set('rewards', JSON.stringify(await validateRewards(b.rewards)));
  if (b.rules !== undefined) set('rules', text(b.rules ?? '', 'Kurallar', { max: 3000 }));
  if (!sets.length) throw fail('Değiştirilecek alan yok.');
  values.push(kind);
  await query(`UPDATE weekly_event_config SET ${sets.join(', ')}, updated_at = NOW() WHERE kind = $${values.length}`, values);
  await query(
    `INSERT INTO financial_audit_logs(admin_id, action, reference_type, reference_id, metadata) VALUES($1,'weekly_event_config','weekly_event',$2,$3)`,
    [req.user.id, kind, JSON.stringify(Object.keys(b))],
  );
  res.json({ ok: true });
});

// ---------- Banner ve duyuru yönetimi (yalnızca yönetici) ----------
router.get('/banners', async (_req, res) => {
  const r = await query(`SELECT id, image_url, title, link_url, sort_order, is_active FROM banners ORDER BY sort_order, created_at DESC LIMIT 50`);
  res.json({ banners: r.rows.map((b) => ({ id: b.id, imageUrl: b.image_url, title: b.title, linkUrl: b.link_url, sortOrder: b.sort_order, active: b.is_active })) });
});

router.put('/banners/image', express.raw({ type: Object.keys(IMAGE_TYPES), limit: '3mb' }), async (req, res) => {
  res.json({ url: await saveUpload(req, 'banner') });
});

router.post('/banners', async (req, res) => {
  const imageUrl = String(req.body?.imageUrl ?? '');
  if (!OWN_IMAGE_RE.test(imageUrl)) throw fail('Önce bir görsel yükleyin.');
  const title = text(req.body?.title, 'Başlık', { max: 80 }) || null;
  const linkUrl = req.body?.linkUrl ? httpsUrl(req.body.linkUrl, 'Bağlantı') : null;
  const sortOrder = Number.isInteger(req.body?.sortOrder) ? req.body.sortOrder : 0;
  const r = await query(`INSERT INTO banners(image_url, title, link_url, sort_order) VALUES($1,$2,$3,$4) RETURNING id`, [imageUrl, title, linkUrl, sortOrder]);
  await auditStaff({ query }, req.user.id, null, 'banner_add', { id: r.rows[0].id });
  res.status(201).json({ id: r.rows[0].id });
});

router.patch('/banners/:id', async (req, res) => {
  const id = uuid(req.params.id);
  if (typeof req.body?.active !== 'boolean') throw fail('active alanı true/false olmalı.');
  const r = await query(`UPDATE banners SET is_active = $2 WHERE id = $1`, [id, req.body.active]);
  if (!r.rowCount) throw fail('Banner bulunamadı.', 404);
  res.json({ ok: true });
});

router.delete('/banners/:id', async (req, res) => {
  const id = uuid(req.params.id);
  const r = await query(`DELETE FROM banners WHERE id = $1 RETURNING image_url`, [id]);
  if (!r.rowCount) throw fail('Banner bulunamadı.', 404);
  await removeUpload(r.rows[0].image_url);
  await auditStaff({ query }, req.user.id, null, 'banner_delete', { id });
  res.json({ ok: true });
});

// Duyuru kartı görseli (Mesajlar > Ekip / Etkinlik / Ödül).
router.put('/announcements/image', express.raw({ type: Object.keys(IMAGE_TYPES), limit: '3mb' }), async (req, res) => {
  res.json({ url: await saveUpload(req, 'announcement') });
});

// Telefon bildirimi: uygulaması yüklü herkese. Açık uygulamalara anında (soket), kapalı/arka plandakilere
// uygulama açılınca telefon bildirimi olarak düşer.
router.get('/push', requireSuperAdmin, async (_req, res) => {
  const r = await query(`SELECT id, title, body, created_at FROM push_messages ORDER BY id DESC LIMIT 30`);
  res.json({ messages: r.rows.map((x) => ({ id: String(x.id), title: x.title, body: x.body, createdAt: x.created_at })) });
});

router.post('/push', requireSuperAdmin, userLimit('admin_push', 20, 3600e3), async (req, res) => {
  const title = text(req.body?.title, 'Başlık', { min: 2, max: 80, required: true });
  const body = text(req.body?.body, 'Mesaj', { min: 2, max: 300, required: true });
  const r = (await query(`INSERT INTO push_messages(title, body, created_by) VALUES($1,$2,$3) RETURNING id, created_at`, [title, body, req.user.id])).rows[0];
  hub.broadcastGlobal({ type: 'push', id: String(r.id), title, body });
  res.status(201).json({ ok: true, id: String(r.id) });
});

router.post('/announcements', async (req, res) => {
  const kind = oneOf(req.body?.kind, ['team', 'event', 'reward'], 'Tür');
  const title = text(req.body?.title, 'Başlık', { min: 2, max: 80, required: true });
  const body = text(req.body?.text, 'Metin', { min: 1, max: 2000, required: true });
  let imageUrl = null;
  if (req.body?.imageUrl) {
    imageUrl = String(req.body.imageUrl);
    if (!OWN_IMAGE_RE.test(imageUrl)) throw fail('Görsel adresi geçersiz.');
  }
  const linkUrl = req.body?.linkUrl ? httpsUrl(req.body.linkUrl, 'Bağlantı') : null;
  const r = await query(
    `INSERT INTO announcements(kind, title, body, created_by, image_url, link_url) VALUES($1,$2,$3,$4,$5,$6) RETURNING id`,
    [kind, title, body, req.user.id, imageUrl, linkUrl],
  );
  await auditStaff({ query }, req.user.id, null, 'announcement_add', { id: r.rows[0].id, kind });
  res.status(201).json({ id: r.rows[0].id });
});

router.delete('/announcements/:id', async (req, res) => {
  const id = uuid(req.params.id);
  const r = await query(`DELETE FROM announcements WHERE id = $1 RETURNING image_url`, [id]);
  if (!r.rowCount) throw fail('Duyuru bulunamadı.', 404);
  await removeUpload(r.rows[0].image_url);
  res.json({ ok: true });
});

// ================= Canlı panel, hata kayıtları, işlem kaydı, uzaktan ayarlar, moderasyon =================
const PKG_VERSION = (() => {
  try { return JSON.parse(fs.readFileSync(new URL('../../package.json', import.meta.url), 'utf8')).version; } catch { return null; }
})();

// CPU kullanımı: iki panel isteği arasındaki ortalama (tek çekirdeğe göre yüzde).
let cpuSample = { at: Date.now(), usage: process.cpuUsage() };
function cpuPercent() {
  const now = Date.now();
  const used = process.cpuUsage(cpuSample.usage);
  const elapsed = Math.max(1, now - cpuSample.at);
  cpuSample = { at: now, usage: process.cpuUsage() };
  return Math.round(((used.user + used.system) / 1000 / elapsed) * 1000) / 10;
}

const mb = (n) => Math.round((Number(n) / 1048576) * 10) / 10;
// "Bugün" Türkiye saatine göre gece yarısından başlar.
const DASH_SQL = `
  WITH d AS (SELECT (date_trunc('day', NOW() AT TIME ZONE 'Europe/Istanbul') AT TIME ZONE 'Europe/Istanbul') AS start)
  SELECT
    (SELECT COUNT(*)::int FROM users, d WHERE users.created_at >= d.start) AS new_users,
    (SELECT COUNT(*)::int FROM users, d WHERE users.last_seen_at >= d.start) AS active_users,
    (SELECT COUNT(*)::int FROM users WHERE account_status = 'active') AS total_users,
    (SELECT COUNT(*)::int FROM gift_transactions g, d WHERE g.created_at >= d.start) AS gifts,
    (SELECT COALESCE(SUM(g.coin_amount), 0)::text FROM gift_transactions g, d WHERE g.created_at >= d.start) AS gift_coins,
    (SELECT COUNT(*)::int FROM room_messages m, d WHERE m.created_at >= d.start) AS room_messages,
    (SELECT COUNT(*)::int FROM direct_messages m, d WHERE m.created_at >= d.start) AS direct_messages,
    (SELECT COUNT(*)::int FROM moderation_strikes s, d WHERE s.created_at >= d.start AND s.kind <> 'auto_mute') AS strikes,
    (SELECT COUNT(*)::int FROM moderation_strikes s, d WHERE s.created_at >= d.start AND s.kind = 'auto_mute') AS auto_mutes,
    (SELECT COUNT(*)::int FROM reports WHERE status = 'open') AS open_reports,
    (SELECT COUNT(*)::int FROM client_errors WHERE created_at > NOW() - INTERVAL '24 hours') AS errors_24h,
    (SELECT COUNT(*)::int FROM rooms WHERE is_active) AS active_rooms,
    (SELECT COUNT(*)::int FROM rooms WHERE is_active AND room_type = 'video') AS video_rooms,
    (SELECT COUNT(*)::int FROM room_members) AS room_members,
    (SELECT COUNT(*)::int FROM room_members WHERE microphone) AS on_mic,
    (SELECT COUNT(*)::int FROM user_sessions WHERE revoked_at IS NULL AND expires_at > NOW()) AS sessions`;

router.get('/dashboard', requireSuperAdmin, async (req, res) => {
  const t0 = Date.now();
  await query('SELECT 1');
  const dbLatencyMs = Date.now() - t0;
  const [stats, size, lk] = await Promise.all([
    query(DASH_SQL),
    query(`SELECT pg_database_size(current_database())::bigint AS bytes, (SELECT COALESCE(SUM(size_bytes), 0)::bigint FROM media_files) AS media`),
    livekitHealth(),
  ]);
  const s = stats.rows[0];
  const mem = process.memoryUsage();
  res.json({
    time: new Date().toISOString(),
    server: {
      version: PKG_VERSION, node: process.version, uptimeSec: Math.round(process.uptime()), cpuPercent: cpuPercent(), cores: os.cpus().length,
      loadAvg: os.loadavg().map((x) => Math.round(x * 100) / 100),
      memory: { rssMb: mb(mem.rss), heapUsedMb: mb(mem.heapUsed), heapTotalMb: mb(mem.heapTotal) },
      host: { totalMb: mb(os.totalmem()), freeMb: mb(os.freemem()) },
    },
    realtime: hub.stats(),
    db: { ok: true, latencyMs: dbLatencyMs, pool: poolStats(), sizeMb: mb(size.rows[0].bytes), mediaMb: mb(size.rows[0].media) },
    livekit: lk,
    mediaCache: { ...mediaCacheStats(), mb: mb(mediaCacheStats().bytes) },
    live: { activeRooms: s.active_rooms, videoRooms: s.video_rooms, audioRooms: s.active_rooms - s.video_rooms, roomMembers: s.room_members, onMic: s.on_mic, sessions: s.sessions },
    today: {
      newUsers: s.new_users, activeUsers: s.active_users, gifts: s.gifts, giftCoins: s.gift_coins,
      roomMessages: s.room_messages, directMessages: s.direct_messages, strikes: s.strikes, autoMutes: s.auto_mutes,
    },
    totals: { users: s.total_users },
    alerts: { openReports: s.open_reports, errors24h: s.errors_24h },
  });
});

router.get('/client-errors', requireSuperAdmin, async (req, res) => {
  const limit = Math.max(1, Math.min(Math.floor(Number(req.query.limit)) || 100, 300));
  const [list, top] = await Promise.all([
    query(
      `SELECT e.id, e.source, e.message, e.stack, e.app_version, e.device, e.occurred_at, e.created_at, u.id AS uid, u.username, u.display_name
       FROM client_errors e LEFT JOIN users u ON u.id = e.user_id ORDER BY e.id DESC LIMIT $1`,
      [limit],
    ),
    query(
      `SELECT source, LEFT(message, 140) AS message, COUNT(*)::int AS n, COUNT(DISTINCT user_id)::int AS users, MAX(created_at) AS last_at
       FROM client_errors WHERE created_at > NOW() - INTERVAL '7 days' GROUP BY 1, 2 ORDER BY n DESC LIMIT 15`,
    ),
  ]);
  res.json({
    errors: list.rows.map((e) => ({
      id: String(e.id), source: e.source, message: e.message, stack: e.stack, appVersion: e.app_version, device: e.device,
      occurredAt: e.occurred_at, createdAt: e.created_at, user: e.uid ? { id: e.uid, username: e.username, displayName: e.display_name } : null,
    })),
    top: top.rows.map((t) => ({ source: t.source, message: t.message, count: t.n, users: t.users, lastAt: t.last_at })),
  });
});

router.delete('/client-errors', requireSuperAdmin, async (req, res) => {
  const r = await query(`DELETE FROM client_errors`);
  res.json({ ok: true, deleted: r.rowCount });
});

// Yönetici/yardımcı admin işlemleri ve para hareketleri tek listede: kim, ne zaman, kime, ne yaptı.
router.get('/actions', requireSuperAdmin, async (req, res) => {
  const limit = Math.max(1, Math.min(Math.floor(Number(req.query.limit)) || 100, 300));
  const userId = req.query.userId ? uuid(String(req.query.userId), 'Kullanıcı') : null;
  const scope = req.query.scope ? oneOf(String(req.query.scope), ['staff', 'user'], 'Kapsam') : null;
  const r = await query(
    `SELECT l.id, l.action, l.reference_type, l.reference_id, l.amount_coins, l.amount_diamonds, l.balance_before, l.balance_after, l.metadata, l.created_at,
            a.id AS actor_id, a.username AS actor_username, a.display_name AS actor_name, a.system_role AS actor_role,
            t.id AS target_id, t.username AS target_username, t.display_name AS target_name
     FROM financial_audit_logs l LEFT JOIN users a ON a.id = l.admin_id LEFT JOIN users t ON t.id = l.user_id
     WHERE ($1::uuid IS NULL OR l.user_id = $1 OR l.admin_id = $1)
       AND ($2::text IS NULL OR ($2 = 'staff' AND l.admin_id IS NOT NULL) OR ($2 = 'user' AND l.admin_id IS NULL))
     ORDER BY l.created_at DESC LIMIT $3`,
    [userId, scope, limit],
  );
  res.json({
    actions: r.rows.map((x) => ({
      id: x.id, action: x.action, referenceType: x.reference_type, referenceId: x.reference_id,
      amountCoins: x.amount_coins == null ? null : String(x.amount_coins), amountDiamonds: x.amount_diamonds == null ? null : String(x.amount_diamonds),
      balanceBefore: x.balance_before == null ? null : String(x.balance_before), balanceAfter: x.balance_after == null ? null : String(x.balance_after),
      metadata: x.metadata, createdAt: x.created_at,
      actor: x.actor_id ? { id: x.actor_id, username: x.actor_username, displayName: x.actor_name, role: x.actor_role } : null,
      target: x.target_id ? { id: x.target_id, username: x.target_username, displayName: x.target_name } : null,
    })),
  });
});

router.get('/app-config', requireSuperAdmin, async (req, res) => {
  res.json({ config: await getConfig(), defaults: CONFIG_DEFAULTS });
});

router.put('/app-config', requireSuperAdmin, async (req, res) => {
  const patch = validateConfigPatch(req.body);
  // Kendi sürümünden yüksek bir "en düşük sürüm" yönetici dahil herkesi uygulamadan kilitlerdi.
  if (patch.minAppVersion && compareVersions(patch.minAppVersion, '0.0.0') > 0) {
    const mine = req.get('X-App-Version');
    if (compareVersions(patch.minAppVersion, mine) > 0) {
      throw fail(`En düşük sürüm, şu an kullandığınız sürümden (${mine || 'bilinmiyor'}) yüksek olamaz; yoksa siz de uygulamaya giremezsiniz.`);
    }
  }
  // Şanslı hediye: gönderene dönen + alıcıya geçen pay hediye değerini aşamaz (platform zarar etmesin).
  const merged = { ...(await getConfig()), ...patch };
  if (merged.luckyRtpBps + merged.luckyReceiverBps > 9500) {
    throw fail('Şanslı hediyede geri dönüş (RTP) + alıcı payı en fazla %95 olabilir.');
  }
  const cfg = await saveConfig(patch, req.user.id);
  await auditStaff({ query }, req.user.id, null, 'app_config_update', patch);
  res.json({ config: cfg });
});

router.get('/moderation/strikes', requireSuperAdmin, async (req, res) => {
  const limit = Math.max(1, Math.min(Math.floor(Number(req.query.limit)) || 100, 300));
  const r = await query(
    `SELECT s.id, s.kind, s.context, s.sample, s.created_at, u.id AS uid, u.public_id, u.username, u.display_name, u.chat_restricted_until
     FROM moderation_strikes s JOIN users u ON u.id = s.user_id ORDER BY s.id DESC LIMIT $1`,
    [limit],
  );
  res.json({
    strikes: r.rows.map((x) => ({
      id: String(x.id), kind: x.kind, context: x.context, sample: x.sample, createdAt: x.created_at,
      user: { id: x.uid, publicId: x.public_id, username: x.username, displayName: x.display_name },
      restrictedUntil: x.chat_restricted_until && new Date(x.chat_restricted_until) > new Date() ? x.chat_restricted_until : null,
    })),
  });
});

// Sohbet kısıtı: dakika (0 = kaldır). Yardımcı admin de kullanabilir (yalnızca normal kullanıcılara).
router.post('/users/:userId/chat-restriction', async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const target = await assertUser(userId);
  if (!mayActOnUser(req.user.system_role, target.system_role)) throw fail('Bu hesap üzerinde işlem yetkiniz yok.', 403);
  const minutes = req.body?.minutes;
  if (!Number.isInteger(minutes) || minutes < 0 || minutes > 10080) throw fail('Süre 0-10080 dakika olmalı (0 = kısıtı kaldır).');
  const r = await query(
    `UPDATE users SET chat_restricted_until = CASE WHEN $2::int = 0 THEN NULL ELSE NOW() + make_interval(mins => $2::int) END WHERE id = $1 RETURNING chat_restricted_until`,
    [userId, minutes],
  );
  await auditStaff({ query }, req.user.id, userId, 'chat_restriction', { minutes, by: req.user.system_role });
  if (minutes > 0) hub.sendToUser(userId, { type: 'chat_restricted', minutes });
  res.json({ ok: true, restrictedUntil: r.rows[0].chat_restricted_until });
});

// Cihazlar: kullanıcının oturumları ve aynı cihazı kullanan diğer hesaplar (çoklu hesap / hile tespiti).
router.get('/users/:userId/devices', requireSuperAdmin, async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  await assertUser(userId);
  const [sessions, linked] = await Promise.all([
    query(
      `SELECT id, device_id, device_name, platform, app_version, emulator, ip, created_at, last_used_at, revoked_at, revoke_reason
       FROM user_sessions WHERE user_id = $1 ORDER BY last_used_at DESC LIMIT 30`,
      [userId],
    ),
    query(
      `SELECT u.id, u.public_id, u.username, u.display_name, u.account_status, MAX(s.last_used_at) AS last_used_at
       FROM user_sessions s JOIN users u ON u.id = s.user_id
       WHERE s.user_id <> $1 AND s.device_id IN (SELECT device_id FROM user_sessions WHERE user_id = $1 AND device_id IS NOT NULL)
       GROUP BY u.id ORDER BY MAX(s.last_used_at) DESC LIMIT 50`,
      [userId],
    ),
  ]);
  res.json({
    sessions: sessions.rows.map((x) => ({
      id: x.id, deviceName: x.device_name, platform: x.platform, appVersion: x.app_version, emulator: x.emulator, ip: x.ip,
      createdAt: x.created_at, lastUsedAt: x.last_used_at, revokedAt: x.revoked_at, revokeReason: x.revoke_reason,
    })),
    online: hub.isOnline(userId),
    linkedAccounts: linked.rows.map((u) => ({ id: u.id, publicId: u.public_id, username: u.username, displayName: u.display_name, accountStatus: u.account_status, lastUsedAt: u.last_used_at })),
  });
});

// ---------------- Giriş bilgileri (yalnızca yönetici) ----------------
// Kullanıcı adı, telefon ve şifre. Şifre hiçbir zaman gösterilmez; yalnızca yenisi verilebilir.
router.get('/users/:userId/credentials', requireSuperAdmin, async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const u = (await query(`SELECT username, phone, (password_hash IS NOT NULL) AS has_password FROM users WHERE id = $1`, [userId])).rows[0];
  if (!u) throw fail('Kullanıcı bulunamadı.', 404);
  res.json({ username: u.username, phone: u.phone ?? '', hasPassword: u.has_password });
});

// Giriş bilgilerini günceller. Gönderilmeyen alan değişmez. phone: '' → telefon kaldırılır.
// Şifre değişince kullanıcının tüm oturumları kapanır (yeni şifreyle yeniden giriş yapar).
router.post('/users/:userId/credentials', requireSuperAdmin, async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const target = await assertUser(userId);
  if (target.account_status === 'deleted') throw fail('Silinmiş hesap değiştirilemez.', 409);
  if (!mayActOnUser(req.user.system_role, target.system_role, userId === req.user.id)) throw fail('Bu hesap üzerinde işlem yetkiniz yok.', 403);
  const b = req.body ?? {};
  const changes = {};
  if (b.username !== undefined && b.username !== null) {
    const username = String(b.username).trim().toLowerCase();
    if (!USERNAME_RE.test(username)) throw fail('Kullanıcı adı 3-30 karakter olmalı; yalnızca harf, rakam, nokta ve alt çizgi kullanılabilir.');
    if (username !== target.username) changes.username = username;
  }
  if (b.phone !== undefined && b.phone !== null) {
    const raw = String(b.phone).trim();
    if (raw === '') {
      changes.phone = null;
    } else {
      const phone = normalizePhone(raw);
      if (!phone) throw fail('Geçerli bir cep telefonu numarası girin (ör. 0555 123 45 67).');
      changes.phone = phone;
    }
  }
  let passwordHash = null;
  if (b.password !== undefined && b.password !== null && String(b.password) !== '') {
    passwordRules(String(b.password));
    passwordHash = await hashPassword(String(b.password));
  }
  if (!Object.keys(changes).length && !passwordHash) throw fail('Değiştirilecek bir bilgi yok.');
  try {
    await tx(async (c) => {
      const before = (await c.query(`SELECT username, phone FROM users WHERE id = $1 FOR UPDATE`, [userId])).rows[0];
      if ('phone' in changes && changes.phone === before.phone) delete changes.phone;
      const sets = []; const vals = [userId];
      for (const [k, v] of Object.entries(changes)) { vals.push(v); sets.push(`${k} = $${vals.length}`); }
      if (passwordHash) { vals.push(passwordHash); sets.push(`password_hash = $${vals.length}`, 'token_version = token_version + 1'); }
      if (sets.length) await c.query(`UPDATE users SET ${sets.join(', ')}, updated_at = NOW() WHERE id = $1`, vals);
      await auditStaff(c, req.user.id, userId, 'credentials_update', {
        username: changes.username ? { before: before.username, after: changes.username } : undefined,
        phone: 'phone' in changes ? { before: before.phone, after: changes.phone } : undefined,
        password: passwordHash ? 'changed' : undefined,
        by: req.user.system_role,
      });
    });
  } catch (error) {
    if (error.code === '23505') throw fail(String(error.constraint ?? '').includes('phone') ? 'Bu telefon numarası başka bir hesapta kayıtlı.' : 'Bu kullanıcı adı zaten kullanılıyor.', 409);
    throw error;
  }
  if (passwordHash) {
    await revokeAllSessions(userId, 'admin_password');
    hub.disconnectUser(userId, 'sessions_revoked');
  }
  const u = (await query(`SELECT username, phone FROM users WHERE id = $1`, [userId])).rows[0];
  res.json({ ok: true, username: u.username, phone: u.phone ?? '', passwordChanged: Boolean(passwordHash) });
});

// Kullanıcının tüm cihazlarındaki oturumları kapatır (hesap çalındı şüphesi vb.).
router.post('/users/:userId/sessions/revoke-all', requireSuperAdmin, async (req, res) => {
  const userId = uuid(req.params.userId, 'Kullanıcı');
  const target = await assertUser(userId);
  if (!mayActOnUser(req.user.system_role, target.system_role) || userId === req.user.id) throw fail('Bu hesap üzerinde işlem yetkiniz yok.', 403);
  await query(`UPDATE users SET token_version = token_version + 1, updated_at = NOW() WHERE id = $1`, [userId]);
  const n = await revokeAllSessions(userId, 'admin');
  hub.disconnectUser(userId, 'sessions_revoked');
  await auditStaff({ query }, req.user.id, userId, 'sessions_revoke', { count: n });
  res.json({ ok: true, revoked: n });
});
