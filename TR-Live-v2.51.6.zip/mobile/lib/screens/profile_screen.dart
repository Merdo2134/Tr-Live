import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api.dart';
import '../services/background_service.dart';
import '../services/auth_service.dart';
import '../services/session.dart';
import '../services/inbox_service.dart';
import '../widgets/anim_asset.dart';
import '../widgets/app_theme.dart';
import '../widgets/lucky_bag.dart';
import '../widgets/common.dart';
import '../widgets/cp_widgets.dart';
import 'admin_screen.dart';
import 'agency_screen.dart';
import 'dealer_screen.dart';
import 'edit_profile_screen.dart';
import 'family_screen.dart';
import 'social_screens.dart';
import 'store_screens.dart';
import 'income_screens.dart';
import 'login_screen.dart';
import 'misc_screens.dart';
import 'support_screens.dart';
import 'user_screens.dart';
import 'wip_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  int _version = 0;

  void _reload() => setState(() => _version++);

  Future<Map<String, dynamic>> _load() async {
    // İki istek aynı anda (sırayla beklenmez).
    final dealerF = Api.get('/api/dealer/me').then((_) => true).catchError((_) => false); // bayi değilse hata döner
    final r = await Api.get('/api/me');
    final profile = mapOf(r['user']) ?? {};
    Session.me.value = profile;
    Inbox.refreshBadges();
    final dealer = await dealerF;
    return {'profile': profile, 'dealer': dealer};
  }

  Future<void> _goLogin() async {
    await AuthService.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
  }

  Future<void> _changePassword() async {
    // Google/Facebook hesabının şifresi yoktur: ilk kez şifre belirlenir (mevcut şifre sorulmaz).
    final has = Session.me.value?['hasPassword'] != false;
    final current = has ? await askText(context, 'Mevcut şifre', obscure: true) : '';
    if (current == null || !mounted) return;
    final next = await askText(context, 'Yeni şifre (en az 6 karakter)', obscure: true);
    if (next == null || !mounted) return;
    final r = await guard(context, () => Api.post('/api/me/password', {'currentPassword': current, 'newPassword': next}));
    if (r != null) {
      if (mounted) toast(context, 'Şifre değişti. Lütfen yeniden giriş yapın.');
      await _goLogin();
    }
  }

  Future<void> _deleteAccount() async {
    if (!await confirm(context, 'Hesabınız ve kişisel verileriniz kalıcı olarak silinir. Bu işlem geri alınamaz.', action: 'Devam')) return;
    if (!mounted) return;
    final has = Session.me.value?['hasPassword'] != false;
    final answer = has ? await askText(context, 'Onay için şifrenizi girin', obscure: true) : await askText(context, 'Onay için SİL yazın');
    if (answer == null || !mounted) return;
    final r = await guard(context, () => Api.delete('/api/me', has ? {'password': answer} : {'confirm': answer}));
    if (r != null) await _goLogin();
  }

  Future<void> _open(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    if (mounted) _reload();
  }

  /// Telefon bildirimi tercihleri (sunucuda saklanır; kapatılan tür hiç gönderilmez).
  Future<void> _notifyPrefs() async {
    final r = await guard(context, () => Api.get('/api/me/notify-prefs'));
    if (r == null || !mounted) return;
    final prefs = Map<String, dynamic>.from(mapOf(r['prefs']) ?? {});
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) {
          Widget sw(String key, String title, String sub) => SwitchListTile(
                title: Text(title),
                subtitle: Text(sub, style: const TextStyle(fontSize: 12)),
                value: prefs[key] != false,
                onChanged: (v) async {
                  setS(() => prefs[key] = v);
                  try {
                    await Api.put('/api/me/notify-prefs', {key: v});
                  } catch (e) {
                    setS(() => prefs[key] = !v);
                    if (c.mounted) toast(c, errorText(e), error: true);
                  }
                },
              );
          return SafeArea(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Padding(padding: EdgeInsets.only(bottom: 4), child: Text('Bildirimler', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
              sw('friend', 'Arkadaşlık', 'Arkadaşlık isteği geldiğinde ve kabul edildiğinde'),
              sw('follow', 'Yeni takipçi', 'Biri seni takip etmeye başladığında'),
              sw('room', 'Arkadaşım oda açınca', 'Arkadaşın oda açtığında (aynı kişiden 30 dakikada bir)'),
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 4, 16, 16),
                child: Text('Uygulama açıkken ya da arka planda çalışırken bildirim hemen gelir; tamamen kapalıysa uygulamayı açınca gösterilir.',
                    style: TextStyle(color: Pal.textDim, fontSize: 12)),
              ),
            ]),
          );
        },
      ),
    );
  }

  Future<void> _openSettings(Map<String, dynamic> p, bool isDealer) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StatefulBuilder(
          builder: (context, setLocal) => Scaffold(
            appBar: AppBar(title: const Text('Ayarlar')),
            body: ListView(children: [
              ListTile(leading: const Icon(Icons.edit), title: const Text('Profili düzenle'), trailing: const Icon(Icons.chevron_right), onTap: () => _open(const EditProfileScreen())),
              ListTile(leading: const Icon(Icons.block), title: const Text('Engellenen kullanıcılar'), trailing: const Icon(Icons.chevron_right), onTap: () => _open(const BlockedUsersScreen())),
              ListTile(leading: const Icon(Icons.notifications_active_outlined), title: const Text('Bildirimler'), subtitle: const Text('Arkadaşlık isteği, yeni takipçi, arkadaşın oda açması'), trailing: const Icon(Icons.chevron_right), onTap: _notifyPrefs),
              ListTile(leading: const Icon(Icons.receipt_long), title: const Text('Cüzdan ve Elmas Bozdurma'), trailing: const Icon(Icons.chevron_right), onTap: () => _open(const WalletScreen())),
              SwitchListTile(
                secondary: const Icon(Icons.visibility_off),
                title: const Text('Gizli kullanıcı modu'),
                subtitle: const Text('Odalarda adınız ve fotoğrafınız gizlenir, aramada çıkmazsınız.'),
                value: p['isHidden'] == true,
                onChanged: (v) async {
                  final r = await guard(context, () => Api.patch('/api/me', {'isHidden': v}));
                  if (r == null || !context.mounted) return; // sunucu reddettiyse anahtar eski hâlinde kalsın
                  p['isHidden'] = v;
                  final me = mapOf(r['user']);
                  if (me != null) Session.me.value = me;
                  toast(context, v ? 'Gizli kullanıcı açık: odalarda ve listelerde herkese (sana da) "Gizli Kullanıcı" görünürsün.' : 'Gizli kullanıcı kapandı.');
                  setLocal(() {});
                },
              ),
              // SWIP ayrıcalığı: hayalet mod (üyelik bitince sunucu kendiliğinden etkisiz sayar).
              if (mapOf(mapOf(p['wip'])?['features'])?['ghostMode'] == true || p['ghostMode'] == true)
                SwitchListTile(
                  secondary: const Text('👻', style: TextStyle(fontSize: 22)),
                  title: const Text('Hayalet mod (SWIP)'),
                  subtitle: const Text('Odaya girişiniz duyurulmaz; dinleyici listesinde, kişi sayısında ve çevrimiçi listelerde görünmezsiniz.'),
                  value: p['ghostMode'] == true,
                  onChanged: (v) async {
                    final r = await guard(context, () => Api.patch('/api/me', {'ghostMode': v}));
                    if (r == null || !context.mounted) return;
                    p['ghostMode'] = v;
                    final me = mapOf(r['user']);
                    if (me != null) Session.me.value = me;
                    toast(context, v
                        ? (me?['ghostActive'] == true ? '👻 Hayalet mod açık: odalarda görünmezsin (mikrofona çıkınca görünürsün).' : 'Hayalet mod yalnızca SWIP üyeliği sürerken çalışır.')
                        : 'Hayalet mod kapandı.');
                    setLocal(() {});
                  },
                ),
              SwitchListTile(
                secondary: const Icon(Icons.online_prediction),
                title: const Text('Çevrimiçi durumumu göster'),
                subtitle: const Text('Kapalıyken kimse çevrimiçi olduğunuzu veya son görülme zamanınızı göremez.'),
                value: p['showPresence'] != false,
                onChanged: (v) async {
                  final r = await guard(context, () => Api.patch('/api/me', {'showPresence': v}));
                  if (r == null || !context.mounted) return;
                  p['showPresence'] = v;
                  setLocal(() {});
                },
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.layers_outlined),
                title: const Text('Arka plan ve balon izinleri'),
                subtitle: const Text('Oda arka planda açık kalsın, diğer uygulamaların üzerinde balon görünsün'),
                onTap: () async {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.remove('asked_battery');
                  await prefs.remove('asked_overlay');
                  if (!context.mounted) return;
                  await BackgroundService.instance.ensurePermissions((msg, action) => confirm(context, msg, action: action));
                },
              ),
              ListTile(leading: const Icon(Icons.bug_report_outlined), title: const Text('Hata kaydı'), trailing: const Icon(Icons.chevron_right), onTap: () => _open(const ErrorLogScreen())),
              ListTile(
                leading: const Icon(Icons.devices),
                title: const Text('Oturumlarım'),
                subtitle: const Text('Hesabınızın açık olduğu cihazlar'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _open(const SessionsScreen()),
              ),
              ListTile(leading: const Icon(Icons.lock_reset), title: const Text('Şifre değiştir'), onTap: _changePassword),
              ListTile(leading: const Icon(Icons.logout), title: const Text('Çıkış yap'), onTap: _goLogin),
              ListTile(leading: const Icon(Icons.delete_forever, color: Colors.redAccent), title: const Text('Hesabı sil', style: TextStyle(color: Colors.redAccent)), onTap: _deleteAccount),
              const SizedBox(height: 24),
            ]),
          ),
        ),
      ),
    );
    if (mounted) _reload();
  }

  Future<void> _copyId(Map<String, dynamic> p) async {
    await Clipboard.setData(ClipboardData(text: '${p['publicId'] ?? ''}'));
    if (mounted) toast(context, 'ID kopyalandı.');
  }

  String? _frameOf(Map<String, dynamic> p) {
    final items = p['equipped'];
    if (items is! List) return null;
    for (final i in items) {
      if (i is Map && i['itemType'] == 'frame') return Api.absoluteUrl(i['assetUrl'] as String?);
    }
    return null;
  }

  Widget _header(Map<String, dynamic> p) {
    final frame = _frameOf(p);
    final wip = mapOf(p['wip']);
    final features = mapOf(wip?['features']);
    const avatarR = 44.0;
    const frameSize = avatarR * 2 * kFrameScale; // çerçeve, fotoğrafın çapına göre
    return Column(children: [
      SizedBox(
        width: frameSize,
        height: frameSize,
        child: Stack(alignment: Alignment.center, children: [
          // Profil efekti (WIP 5+): avatarın arkasında ışık halesi.
          if (features?['profileEffect'] == true && wipLevelOf(wip?['level']) != null)
            Positioned.fill(child: IgnorePointer(child: WipAura(level: wipLevelOf(wip?['level'])!))),
          UserAvatar(user: p, radius: avatarR),
          // Takılı çerçeve yoksa WIP kademesinin çerçevesi.
          if (frame == null && wipLevelOf(wip?['level']) != null)
            Positioned.fill(child: IgnorePointer(child: WipFrame(level: wipLevelOf(wip?['level'])!, avatarRadius: avatarR))),
          if (frame != null) IgnorePointer(child: SizedBox(width: frameSize, height: frameSize, child: AnimAsset(url: frame, repeat: true, cache: false))),
        ]),
      ),
      UserName(
        user: {'displayName': p['displayName'], 'wipLevel': wip?['level'], 'nameColor': features?['nameColor']},
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
      ),
      const SizedBox(height: 2),
      InkWell(
        onTap: () => _copyId(p),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Text('ID: ${p['publicId'] ?? '-'}', style: const TextStyle(color: Pal.textDim, fontSize: 12.5)),
            const SizedBox(width: 6),
            const Icon(Icons.copy, size: 14, color: Pal.textDim),
          ]),
        ),
      ),
    ]);
  }

  Widget _statsRow(Map<String, dynamic> p) {
    return ValueListenableBuilder<Map<String, int>>(
      valueListenable: Inbox.badges,
      builder: (context, b, _) {
        Widget stat(String label, dynamic value, int badge, VoidCallback onTap) => Expanded(
              child: InkWell(
                onTap: onTap,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Column(children: [
                    FittedBox(fit: BoxFit.scaleDown, child: Text(label, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, letterSpacing: 0.3, color: Pal.textDim))),
                    const SizedBox(height: 4),
                    Badge(
                      label: Text('$badge'),
                      isLabelVisible: badge > 0,
                      alignment: Alignment.topRight,
                      offset: const Offset(10, -8),
                      child: Text(fmtNumber(value), style: const TextStyle(color: Pal.cyan, fontSize: 15, fontWeight: FontWeight.w700)),
                    ),
                  ]),
                ),
              ),
            );
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(color: Pal.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pal.outline)),
          child: Row(children: [
            stat('TAKİP EDİLEN', p['following'], 0, () => _open(UserListScreen(title: 'Takip edilenler', path: '/api/users/${p['id']}/following'))),
            stat('FANLAR', p['followers'], b['followers'] ?? 0, () async {
              await _open(UserListScreen(title: 'Fanlar', path: '/api/users/${p['id']}/followers'));
              Inbox.markSeen('followers');
            }),
            stat('ZİYARETÇİLER', p['visitorCount'], b['visitors'] ?? 0, () async {
              await _open(const VisitorsScreen());
              Inbox.markSeen('visitors');
            }),
            stat('ARKADAŞLAR', p['friends'], b['friends'] ?? 0, () => _open(const FriendsScreen())),
          ]),
        );
      },
    );
  }

  Widget _moneyCards(Map<String, dynamic> p) {
    Widget card(List<Color> colors, Widget icon, dynamic value, String label, Color textColor, VoidCallback onTap) => Expanded(
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Container(
              height: 56,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), gradient: LinearGradient(colors: colors)),
              child: Row(children: [
                icon,
                const SizedBox(width: 10),
                Expanded(
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    FittedBox(fit: BoxFit.scaleDown, child: Text(fmtNumber(value), style: TextStyle(color: textColor, fontSize: 15, fontWeight: FontWeight.w800))),
                    FittedBox(fit: BoxFit.scaleDown, child: Text(label, style: TextStyle(color: textColor, fontSize: 11.5, fontWeight: FontWeight.w600))),
                  ]),
                ),
                Icon(Icons.chevron_right, color: textColor),
              ]),
            ),
          ),
        );
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 14, 12, 0),
      child: Row(children: [
        card(const [Color(0xFFFFE259), Color(0xFFFFC107)], const Icon(Icons.monetization_on, color: Color(0xFFB26A00), size: 34), p['coins'], 'Coins Yükleme', const Color(0xFF3B2A00), () => _open(const CoinsCenterScreen())),
        const SizedBox(width: 10),
        card(const [Color(0xFF5E6B8C), Color(0xFF8A94AD)], const Icon(Icons.diamond, color: Colors.cyanAccent, size: 32), p['diamonds'], 'Gelir Merkezi', Colors.white, () => _open(const IncomeCenterScreen())),
      ]),
    );
  }

  Widget _quickTiles(Map<String, dynamic> p) {
    final wip = mapOf(p['wip']);
    Widget tile(IconData icon, Color color, String label, VoidCallback onTap) => Expanded(
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [color.withValues(alpha: 0.35), color.withValues(alpha: 0.08)])),
                  child: Icon(icon, size: 26, color: color),
                ),
                const SizedBox(height: 5),
                Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.5, color: Pal.text)),
              ]),
            ),
          ),
        );
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
      child: Row(children: [
        tile(Icons.military_tech, Colors.amber, 'Leveller', () => _open(const LevelsScreen())),
        tile(Icons.groups, Colors.orangeAccent, 'Aile', () => _open(Scaffold(appBar: AppBar(title: const Text('Aile')), body: const FamilyScreen()))),
        tile(Icons.workspace_premium, Colors.lightBlueAccent, wip == null ? 'WIP' : wipLabel(wipLevelOf(wip['level'])), () => _open(const WipScreen())),
        tile(Icons.checkroom, Colors.pinkAccent, 'Görünüm', () => _open(const AppearanceScreen())),
      ]),
    );
  }

  Widget _menu(Map<String, dynamic> p, bool isDealer) {
    final agencyOwned = mapOf(p['agencyOwned']);
    final broadcasterStatus = p['broadcasterStatus']?.toString();
    final isBroadcaster = broadcasterStatus == 'approved';
    Widget row(IconData icon, Color color, String title, VoidCallback onTap, {String? sub}) => ListTile(
          leading: Container(width: 36, height: 36, decoration: BoxDecoration(color: color.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(10)), child: Icon(icon, color: color, size: 20)),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14.5)),
          subtitle: sub == null ? null : Text(sub, style: const TextStyle(fontSize: 11.5, color: Pal.textDim)),
          dense: true,
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        );
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 10, 12, 0),
      decoration: BoxDecoration(color: Pal.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pal.outline)),
      child: Column(children: [
        row(Icons.storefront, Colors.orangeAccent, 'Mağaza', () => _open(const StoreScreen())),
        // Yayıncı Merkezi: yalnızca ajans davetini kabul etmiş (onaylı) yayıncılar. Başvuru yok; davet Mesajlar'a düşer.
        if (isBroadcaster) row(Icons.podcasts, Colors.pinkAccent, 'Yayıncı Merkezi', () => _open(const AgencyScreen(mode: 'broadcaster'))),
        // Ajans Merkezi: yalnızca ajans sahibi (ajansı yönetici açar). Ajans sahibi aynı zamanda yayıncı da olabilir.
        if (agencyOwned != null) row(Icons.business, Colors.lightBlueAccent, 'Ajans Merkezi', () => _open(const AgencyScreen(mode: 'agency')), sub: '${agencyOwned['name']} · ${const {'pending': 'İnceleniyor', 'active': 'Aktif', 'suspended': 'Askıda', 'rejected': 'Reddedildi'}[agencyOwned['status']] ?? agencyOwned['status']}'),
        row(Icons.task_alt, Colors.greenAccent, 'Günlük Görevler', () => showDailySheet(context)),
        if (isDealer) row(Icons.store_mall_directory, Colors.tealAccent, 'Bayi paneli', () => _open(const DealerScreen())),
        if (Session.isStaff) row(Icons.admin_panel_settings, Colors.redAccent, Session.isAdmin ? 'Yönetim paneli' : 'Yardımcı admin paneli', () => _open(const AdminScreen())),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AsyncBody<Map<String, dynamic>>(
      version: _version,
      load: _load,
      builder: (context, data, reload) {
        final p = mapOf(data['profile']) ?? {};
        final isDealer = data['dealer'] == true;
        return RefreshIndicator(
          onRefresh: reload,
          child: ListView(padding: const EdgeInsets.only(bottom: 24), children: [
            // Üst çubuk zaten durum çubuğunu karşılıyor: burada ikinci bir SafeArea boşluğu yok.
            // Müşteri hizmetleri ve düzenle simgeleri çerçevenin sağ üstüne biner (yer kaplamaz).
            Stack(children: [
              Padding(padding: const EdgeInsets.only(top: 6), child: Center(child: _header(p))),
              Positioned(
                top: 0,
                right: 4,
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(tooltip: 'Müşteri hizmetleri', icon: const Icon(Icons.headset_mic_outlined, size: 22), onPressed: () => _open(const CustomerServiceScreen())),
                  IconButton(tooltip: 'Profili düzenle', icon: const Icon(Icons.edit_outlined, size: 22), onPressed: () => _open(const EditProfileScreen())),
                ]),
              ),
            ]),
            _statsRow(p),
            // CP eşi (onaylı CP ilişkisi varsa).
            if (mapOf(p['cp'])?['partner'] != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
                child: CpPartnerCard(
                  cp: mapOf(p['cp'])!,
                  onTap: () {
                    final id = mapOf(mapOf(p['cp'])?['partner'])?['id']?.toString();
                    if (id != null) _open(UserProfileScreen(userId: id));
                  },
                ),
              ),
            _moneyCards(p),
            _quickTiles(p),
            _menu(p, isDealer),
            Container(
              margin: const EdgeInsets.fromLTRB(12, 10, 12, 0),
              decoration: BoxDecoration(color: Pal.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pal.outline)),
              child: ListTile(
                dense: true,
                leading: Container(width: 36, height: 36, decoration: BoxDecoration(color: Pal.cyan.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.settings, color: Pal.cyan, size: 20)),
                title: const Text('Ayarlar', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14.5)),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _openSettings(p, isDealer),
              ),
            ),
          ]),
        );
      },
    );
  }
}
